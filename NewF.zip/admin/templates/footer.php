<div id="footer">
	<span class="tip"><a  href="#" title="Just-FastFood Admin" >JFF Solutions Limited</a></span> &copy; Copyright 2012.  All Right Reserved
	<div style="text-align:right">Powered By <span class=""><a  href="http://just-fastfood.com" target="_blank" title="Powered and Design by" >Just-FastFood</a></span></div>
</div>