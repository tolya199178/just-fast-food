<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kunle
 * Date: 11/10/13
 * Time: 13:08
 * To change this template use File | Settings | File Templates.
 */

class Labels {

    const JustFastFood              = "Just-FastFood";
    const JustFastFoodTag           = "Order Your Favourite Fast Food";
    const JustFastFoodTag2          = "Takeaways Online";
    //const OpeningHours              = "Opening Hours";
    //const OrderSent                 = "Your Order is being sent to our drivers";
    //const OrderId                   = "Your Order ID : ";
    //const TransactionID             = "Your Transaction ID : ";
    //const ThankYou                  = "Thank You";
    //const OrderStatus               = "Please check your order status below.";
}