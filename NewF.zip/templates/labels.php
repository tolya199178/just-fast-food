<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kunle
 * Date: 11/10/13
 * Time: 13:08
 * To change this template use File | Settings | File Templates.
 */

class Labels {

    const OpeningHours = "Opening Hours";
}