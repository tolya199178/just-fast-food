<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kunle
 * Date: 19/09/13
 * Time: 12:00
 * To change this template use File | Settings | File Templates.
 */
session_start();
include('include/functions.php');