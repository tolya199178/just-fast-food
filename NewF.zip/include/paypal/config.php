<?php
$PayPalMode 			= 'live'; // sandbox or live

$PayPalApiUsername 		= 'awaisk_1349926600_biz_api1.yahoo.com'; //PayPal API Username
$PayPalApiPassword 		= '1349926631'; //Paypal API password
$PayPalApiSignature 	= 'AFcWxV21C7fd0v3bYYYRCpSSRl31A4IYu3nowsFclMPQ81jktAn3aj3s'; //Paypal API Signature

/* $PayPalApiUsername 		= 'awaiskhan88172_api1.yahoo.com'; //PayPal API Username
$PayPalApiPassword 		= 'GQP37XJMQA7MBR4D'; //Paypal API password
$PayPalApiSignature 	= 'AT-dASviI3vvpxRCO0rLqnYFzdBDAAOU9r0oRDJEo0W6GYmFMzHMyV8N'; //Paypal API Signature */

$PayPalApiUsername 		= 'smartdelivery_api1.outlook.com'; //PayPal API Username
$PayPalApiPassword 		= '32T2YKXQFDNJ8VY3'; //Paypal API password
$PayPalApiSignature 	= 'ABUQTY1RaDqyl5JXGVmVsIvCFPZeAL-qUa5Wg8f821mX00Nn4vZDfk5V'; //Paypal API Signature

$PayPalCurrencyCode 	= 'GBP'; //Paypal Currency Code
$PayPalReturnURL 		= 'https://just-fastfood.com/include/paypal/process.php'; //Point to process.php page
$PayPalCancelURL 		= 'https://just-fastfood.com/order-details.php'; //Cancel URL if user clicks cancel

?>