<?php
/**
 * Created by PhpStorm.
 * User: Kunle
 * Date: 27/03/14
 * Time: 09:49
 */
session_start();
$_SESSION['SESSION'] = md5(time().rand());

global $geoplugin;
setcookie('subType', $_GET['subType']);

include('template/header.php');

require_once('admin/include/dbclass.php');
require_once('include/stripe.config.php');
require_once('include/class.subs.php');


$sid = (int) $_GET['subType'];
if(!isset($sid) || empty($sid)) {
	header('Location:index.php');exit;
}

$obj = new subscription;
$subscription = $obj -> getSubscription($sid);
$subscription = $subscription[0];
if(empty($subscription)) {
	header('Location:index.php');exit;
}

$Rmsg = '<p style="text-align:center">Please wait while we process your subscription. DO <span style="text-decoration: underline">not</span> refresh <br/><img src="include/images/ajax-loader.gif" alt=""/></p>';

?>
    <script type="text/javascript" src="https://js.stripe.com/v2/"></script>
    <script type="text/javascript">

        var result;
		function submitHandler(){

           result = $('#pp-dialog .modal-content .result');
		   $('#pp-dialog').modal();
			result.html('<?php echo $Rmsg; ?>');
            var Email = $('#Email').val().trim(), ccNum = $('#card_no').val().trim(), cvcNum = $('#csc').val().trim(), expMonth = $('#MM').val().trim(), expYear = $('#YYYY').val().trim(), Name = $('#f_name').val().trim() + ' ' + $('#l_name').val().trim();

            var Addr = '';
            var Zip = '';
			if($('#N_Addr').val() != ''){
                Addr = $('#N_Addr').val();
            }
            if($('#N_Postcode').val() != ''){
                Zip = $('#N_Postcode').val();
            }

            Stripe.setPublishableKey("<?php echo STRIPE_TEST_PK; ?>");
            Stripe.createToken({
                number: ccNum,
                cvc: cvcNum,
                exp_month: expMonth,
                exp_year: expYear,
                name : Name,
                address_line1 : Addr,
                address_zip : Zip,
				email : Email
            }, stripeResponseHandler);
            return false;

        }

        function stripeResponseHandler(status, response) {

            if (response.error) {
                html = '<div class="alert alert-danger fade in"><h4>Error!</h4><p>'+response.error.message+'</p></div>';
                result.html(html);
            } else { // No errors, submit the form:
                var f = $("#signup-form");
                // Token contains id, last4, and card type:
                var token = response['id'];
                // Insert the token into the form so it gets submitted to the server
                f.append("<input type='hidden' name='stripeToken' value='" + token + "' />");
                localStorage.setItem("token1",token);
                $('#SESSION').val('<?php echo $_SESSION['SESSION']; ?>');
                // Submit the form:
                //f.get(0).submit();

                $.ajax({
                    type: "POST",
                    url: "include/card/process.php",
                    data: f.serialize()
                }).done(function(msg) {
                    result.html(msg);
					if(msg.indexOf('successful') !=-1 ) {
						$('#nextSubmit').removeAttr('onclick');
						f.find('fieldset').hide();
						f.find('.confirmation').show();
					}
                });
            }
        }

    </script>

    <div class="modal fade" id="pp-dialog" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                    <h4 class="modal-title" id="myLargeModalLabel">Card Processing</h4>
                </div>
                <div class="modal-body result">
					<?php echo $Rmsg; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="clearfix"></div>
    <hr class="sep1">
    <!--Slider -->
    <div class="big_image0">
        <div class="form-container" style="width: 90%">
            <div class="container">
                <ul id="progressbar">
                    <li class="active">Personal Information</li>
                    <li>Payment</li>
                    <li>Confirmation</li>
                </ul>
                <form id="signup-form" method="post" action="">
                    <fieldset>
                        <h2 class="text-left" style="color: #575790">Please enter your information below</h2> <span><h5 class="text-left gray"> </h5></span>

                        <input id="f_name" class="" type="text" placeholder="Enter your first name" name="firstName" data-parsley-range="[4, 20]" data-parsley-group="block1" data-placement="top" data-toggle="tooltip" title="Please enter your first name." required autofocus/>
                        <input id="l_name" class="" type="text" placeholder="Enter your last name" name="lastName" data-parsley-range="[4, 20]" data-parsley-group="block1" data-placement="top"  data-toggle="tooltip" title="Please enter your last name" required />
                        <input id="Email" class="email" type="email" data-parsley-trigger="change" placeholder="Enter your email" name="email" data-placement="top" required data-toggle="tooltip" title="We will send your confirmation to this email." />
                        <input id="N_Addr" class="" type="text" data-parsley-trigger="change" placeholder="Enter your address" name="address" data-placement="top" required data-toggle="tooltip" title="Please enter your address"  />
                        <input id="mce-PASSWORD" class="" type="text" data-parsley-trigger="change" placeholder="City" name="city" data-placement="top" required data-toggle="tooltip" title="Please enter your city address"/>
                        <input id="N_Postcode" class="postcode" type="text" data-parsley-trigger="change" placeholder="Enter your <?php if($geoplugin->countryCode == "GB") { echo 'postcode';} else { echo 'zipcode';};?>" name="password" data-placement="top" required data-toggle="tooltip" title="For example, SE13 1FG"/>
                        <input type="button" name="next" id="nextPay" class="next action-button" value="Next" />
						<div class="clearfix"></div>
					</fieldset>
                    <fieldset>
                        <h2 class="text-left" style="color: #575790">Please enter your payment information</h2> <span><h5 class="text-left gray"> </h5></span>
                        <select name="select" id="select" class="select" required="required">
                            <option value="">Select Card Type</option>
                            <option value="visa">Visa</option>
                            <option value="master">Mastercard </option>
                            <option value="debt">Visa Debit </option>
                            <option value="dis">Discover </option>
                            <option value="exp">American Express </option>
                        </select>
                        <input id="card_no" class="credit_card_number" type="pwd" placeholder="Enter your card number" name="cardnumber" data-placement="right" required data-toggle="tooltip" title="e.g 4657488599687784" autocomplete="on" autocompletetype="cc-number">
                        <div >
                            <select name="month" id="MM" class="month" required="required" autocompletetype="cc-exp">
                                <option value="">Expiry Month</option>
                                <?php
                                $month = array('01'=>'Jan', '02'=>'Feb' , '03'=>'Mar' ,'04'=>'Apr' ,'05'=>'May' , '06'=>'Jun' , '07'=>'Jul' , '08'=>'Aug' , '09'=>'Sep' , '10'=>'Oct' , '11'=>'Nov' ,'12'=>'Dec');
                                foreach($month as $k => $m) {
                                    echo '<option value="'.$k.'">'.$k.' ('.$m.') </option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div >
                            <select name="year" id="YYYY" class="year" autocompletetype="cc-exp">
                                <option value="">Expiry Year</option>
                                <?php
                                $now = date('Y');
                                for($i = $now ; $i < $now + 11 ; $i ++) {
                                    $y = substr($i, strlen($i)-2, 2);
                                    echo '<option value="'.$y.'">'.$i.'</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <input id="csc" class="credit_card_cvc" type="number" placeholder="CVV" name="cardcvv" data-placement="right" required data-toggle="tooltip" autocomplete="off" autocompletetype="cc-csc">
                        <input id="mce-PASSWORD" class="phone_number" type="text" placeholder="Enter your phone number" name="phoneno" data-placement="right" required data-toggle="tooltip" autocomplete="off">
                         <span style="float: left; clear: both">
                           <input id="mce-check" class="fom-control" type="checkbox" value="terms">
                        </span>
                        <span class="agreeTerms">
                            I agree with the
                                <a target="_blank" href="terms-condition.html"> terms and conditions</a>
                        </span>
						<div class="clearfix"></div>
                        <input type="button" onclick="submitHandler()" name="addUser" class="action-button" id="nextSubmit" value="Place Order" tooltip="Please complete the missing fields" data-toggle="tooltip" data-placement="right" />
                        <input type="hidden" name="SESSION" id="SESSION" value=""/>
						<input type="hidden" name="subId" value="<?php echo $subscription -> subid?>"/>
						<div class="clearfix"></div>
					</fieldset>
                    <fieldset class="confirmation">
                        <h2 class="text-left" style="color: #575790">Confirmation</h2> <span><h5 class="text-left gray"> </h5></span>
                        <span>Thank you for subscribing. Please check your email for confirmation.</span>
                    </fieldset>
                </form>

            </div>
            <div class="rightSection">
                <div class="headDisplay">
                    <h5>
                        FOR BILLING ISSUES
                        <br>
                        OR CUSTOMER COMPLAINTS
                        <br>
                        <span>Call</span>
                        <strong>1 866 914 9049</strong>
                    </h5>
                    <h4 style="float: right; margin-top: -4em"><?php if ($_GET['h'] == 1 && ($_GET['subType'] == 'basic')) { echo $geoplugin->convert(19.99, 2, true); } else if (($_GET['h'] == 1) && ($_GET['subType'] == 'prem')){ echo $geoplugin->convert(80.00, 2, true);; }else { echo $geoplugin->convert(49.00, 2, true);}?></h4>
					<h4 style="float: right; margin-top: -4em">&pound;<?php $subscription -> price ?></h4>
				</div>
                <div class="price" id="bottomSection">
					<div class="small_title">
						<h3><b><?php echo $subscription -> subtitle ?></b></h3>
					</div>
					<ul class="list-unstyled">
						<?php
							$subdetail = json_decode($subscription -> description);
							foreach($subdetail as $d) {
						?>
								<li class="basic float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px; color: green"></span><?php echo $d ?></li>
						<?php
							}
						?>
					</ul>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="clearfix"></div>
<?php include('template/footer.php');?>