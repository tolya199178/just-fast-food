<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kunle
 * Date: 23/03/14
 * Time: 15:25
 * To change this template use File | Settings | File Templates.
 */
?>
<!--JS INLCUDES-->
<script src="include/js/jquery-1.7.2.min.js"></script>
<script src="include/js/superfish.js"></script>
<script src="include/js/responsive-nav.js"></script>
<script src="include/js/bootstrap.min.js"></script>
<script src="include/js/owl.carousel.min.js"></script>
<script src="include/js/custom.js" type="text/javascript"></script>
<script src="include/js/textillate.js" type="text/javascript"></script>
<script src="include/js/countUp.js" type="text/javascript"></script>
<script src="include/js/jquery.easing.min.js" type="text/javascript"></script>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<script src="include/js/parsely.min.js" type="text/javascript"></script>
<script src="include/js/selectonic.js" type="text/javascript"></script>
<script src="include/js/jquery.easydropdown.min.js" type="text/javascript"></script>
<script src="include/js/jquery.formance.min.js" type="text/javascript"></script>
<script src="include/js/jquery.stickyNavbar.min.js" type="text/javascript"></script>

<div class="section_bottom">
    <div class="container">

        <div class="section_top_inner">
            <div class="top_left col-lg-7 col-sm-8">
                <div class="items">
                    <ul>
                        <li><img src="include/images/phone.png"></li>
                        <li>Customer Care - <span>1 800 237 3901</span></li>


                    </ul>
                </div>

                <div class="items">
                    <ul>
                        <li><img src="include/images/chat.png"></li>
                        <li><a href=""><span>Live Chat</span>
                                with technical expert</a></li>


                    </ul>
                </div>

            </div>
            <div class="top_right col-lg-5 col-sm-4">

                <div class="social">
                    <ul>
                        <li><a href=""><img src="include/images/fb.png" /></a></li>
                        <li><a href=""><img src="include/images/twitter.png" /></a></li>
                        <li><a href=""><img src="include/images/linkedin.png" /></a></li>
                        <li><a href=""><img src="include/images/youtube.png" /></a></li>

                    </ul>
                </div>

            </div>

        </div>
    </div>
</div>