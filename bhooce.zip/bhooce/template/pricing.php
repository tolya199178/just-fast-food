<?php
global $geoplugin;
// pricing
global $priceHourly;
global $priceMonthly;
global $priceOneOff;
 $priceMonthly = $geoplugin->convert(19.99, 2, true);
 $priceHourly = $geoplugin->convert(80.00, 2, true);
 $priceOneOff = $geoplugin->convert(49.00, 2, true);
 //$priceHourly = $priceHourly.'0';
 //$priceOneOff = $priceOneOff.'0';

	require_once('include/class.subs.php');
?>
<div class="section_packages">
    <div class="container animation-container" id="pricing">
        <div class="title"><h2 class="white shadow text-center" style="font-family: 'Roboto', sans-serif">Just select the service that fits your needs<br>
            and leave the rest to us. </h2></div>
		<?php
			$obj = new subscription;
			$subscriptions = $obj -> getSubscription();
			foreach($subscriptions as $subscription){
				$details = json_decode($subscription -> description);
		?>
			<div class="package grow">
				<ul>
					<li class="p_title"><?php echo $subscription -> subtitle ?></li>
					<li class="price">&pound;<?php echo $subscription -> price ?><span><?php echo $subscription -> ptitle ?></span></li>
					<?php
						foreach($details as $d) {
							if($d == '') continue;
					?>
						<li class="features"><img src="include/images/tick.png"> <?php echo $d ?></li>
					<?php } ?>
				</ul>
				<div class="custom_button_large" >
					<ul>
						<li class="red_btn" id="basic"> <a href="subscribe.php?h=1&subType=<?php echo $subscription -> subid ?>">Subscribe Now </a></li>
					</ul>
				</div>
			</div>
		<?php } ?>
          <?php if (false && $_COOKIE['language'] == 'GB' || $_COOKIE['language'] == 'US') { ?>
        <div class="package grow">
            <ul>
                <li class="p_title">Repair Services</li>
                <li class="price"><?php echo $priceOneOff;?> <span>Per Session</span></li>
                <li class="features"><img src="include/images/tick.png">Adware/Spyware clean up</li>
                <li class="features"><img src="include/images/tick.png">Virus removal and protection verification</li>
                <li class="features"><img src="include/images/tick.png">Antivirus installation and configuration</li>
                <li class="features"><img src="include/images/tick.png">Hard drive defragmentaion</li>
                <li class="features"><img src="include/images/tick.png">Startup optimization</li>
                <li class="features"><img src="include/images/tick.png">Temporary files cleanup</li>
                <li class="features"><img src="include/images/tick.png">Computer and Application optimization </li>
            </ul>
            <div class="custom_button_large" >
                <ul>
                    <li class="red_btn" id="one-off"> <a href="subscribe.php?h=1&subType=oneoff">Subscribe Now </a></li>
                </ul>
            </div>
        </div>
          <?php } ?>
        <div class="clearfix"></div>
     <!--   <div class="sep2"></div> -->
    </div>
    </div>
        <div class="section_testimony">
            <div class="title"><h2 class="white shadow text-center">Our Client`s Feedback </h2> <span><h4 class="white text-center">We value our client`s and appreciate their interest and feedback</h4></span></div>
            <div id="owl-demo" class="owl-carousel">
                <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
                    <ul>
                        <li class="client_comments">We couldn't be happier.. Bhooce technicians was on time, resolution within 45 minutes for a 2 hours service. Services rendered saved us so much and still in use.   </li>
                        <li class="desc1"> Brian </li>
                        <li class="desc2">JFF Solutions </li>
                    </ul>
                </div>
                <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
                    <ul>
                        <li class="client_comments">These guys sure knows what they are doing. If you're looking for the best bet for your money and a reliable service, please look no further than this guys!  </li>
                        <li class="desc1"> John </li>
                        <li class="desc2">Marketing WikiTravel </li>
                    </ul>
                </div>
                <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
                    <ul>
                        <li class="client_comments">We got a service worth of $600 minimum for $80. Even more, issues hasn't replicated itself since the engineer left compare to our previous engineers. Good jobs guys!  </li>
                        <li class="desc1"> Ana </li>
                        <li class="desc2">Marketing WikiTravel </li>
                    </ul>
                </div>
                <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
                    <ul>
                        <li class="client_comments">We've relied on Bhooce's services for a while now and not at one time has they failed us! </li>
                        <li class="desc1">Bridget</li>
                        <li class="desc2">Wolfs </li>
                    </ul>
                </div>
            </div>
        <div class="rights"><p class="white text-center">All Rights reserved Bhooce.com, 2014</p></div>
        </div>
</div>