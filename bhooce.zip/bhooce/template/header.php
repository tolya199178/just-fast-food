<?php

require_once('include/class_service/geoplugin.class.php');
require('include/class_service/function.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();

// Set user country name
setcookie('language', $geoplugin->countryCode);

// phone numbers
$phoneNumber = "";
if ($_COOKIE['language'] == 'GB') {
    $phoneNumber = '0 800 453 7764';
} else {
    $phoneNumber = '1 800 237 3901';
}

?>
<!DOCTYPE html>

    <html>
    <head>
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7; IE=EmulateIE9">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Bhooce - On-site & Remote Technical Support</title>

    <!--CSS INCLUDES-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,700italic,800italic,400,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,700italic,900' rel='stylesheet' type='text/css'>



    <link href="include/css/awwal.css" rel="stylesheet">
    <link href="include/css/menu.css" rel="stylesheet">
    <link href="include/css/animate.min.css" rel="stylesheet">
    <link href="include/css/owl.carousel.css" rel="stylesheet">
    <link href="include/css/owl.theme.css" rel="stylesheet">
    <link href="include/css/bootstrap.css" rel="stylesheet">
    <link href="include/css/media.css" rel="stylesheet">
    <link rel="stylesheet" href="include/css/font-awesome/css/font-awesome.css">
    <link href="include/css/hover-min.css" rel="stylesheet" media="all">
    <link href="include/css/easydropdown.css" rel="stylesheet" media="all">


    <!--FONTS INCLUDE-->



    </head>
    <body>
    <div class="background-faded wrapper">
    <header>
    <div class="section_top">
    <div class="container">

        <div class="section_top_inner">
            <div class="top_left col-lg-6 col-sm-6">
                <div class="items">
                   <ul>
                        <li><img src="include/images/phone.png"></li>
                        <li>Customer Care - <span><?php echo($phoneNumber);?></span></li>
                   </ul>
                </div>

                <div class="items">
                    <ul>
                        <li><img src="include/images/chat.png"></li>
                        <li><a href=""><span>Live Chat</span>
    with technical expert</a></li>
                    </ul>
                </div>



            </div>
    <div class="top_right col-lg-6 col-sm-6">
    <div class="social">
          <ul>
            <li><a href=""><img src="include/images/fb.png" /></a></li>
            <li><a href=""><img src="include/images/twitter.png" /></a></li>
            <li><a href=""><img src="include/images/linkedin.png" /></a></li>
            <li><a href=""><img src="include/images/youtube.png" /></a></li>

          </ul>
        </div>
    <div class="login">
                <ul>
                <li><img src="include/images/account.png"><a href="sign-in.php">Sign In</a></li>
                <li><img src="include/images/register.png"><a href="index.php#pricing">Subscribe</a></li>


                </ul>
                </div>

    </div>

    </div>
    </div>
    </div>
        <div class="clearfix"></div>

        <div class="container">
        <div class="section_nav">
    <div class="logo col-lg-3 col-sm-4" ><a href="index.php"><img src="include/images/logo.png" alt="Bhooce"></a> </div>

            <nav id="main_menu" class="col-lg-6 col-sm-8">
              <div class="menu_wrap">
                <ul class="nav sf-menu">
                  <li class="sub-menu"><a href="index.php">Home</a></li>

                  <li class="sub-menu"><a href="about_us.php">About</a></li>

                  <li class="sub-menu"><a href="services.php">Services</a>
                    <ul>
                      <li><a href="diagnosis.php">Home Services </a>
                        <ul style="font-family: "GE Inspira"">
                            <li><a href="#">Virus & Malware Removal</a> </li>
                            <li><a href="#">Data recovery and backup solutions</a> </li>
                            <li><a href="#">Startup optimisation</a> </li>
                            <li><a href="#">Wifi configuration</a> </li>
                        </ul>
                      </li>
                      <li><a href="#">Business Solutions</a>
                          <ul>
                              <li><a href="#">Network infrastructure (routers/firewalls)</a> </li>
                              <li><a href="#">Software installation, rollouts, and upgrades</a> </li>
                              <li><a href="#">Servers</a> </li>
                              <li><a href="#">VoIP installation and configuration</a> </li>
                              <li><a href="#">Onsite & Remote support</a> </li>

                          </ul>
                      </li>
                      <li><a href="#">Enterprise Solutions</a>
                          <ul>
                              <li><a href="#">VPN design, installation and Support</a> </li>
                              <li><a href="#">Printer maintenance</a> </li>
                              <li><a href="#">Hardware repair</a> </li>
                              <li><a href="#">Wireless network repair</a> </li>
                          </ul>
                      </li>

                    </ul>
                  </li>



                  <li class="sub-menu"><a href="support.php">Support</a></li>



                  <li class="sub-menu"><a href="contact.php">Contact</a>

                  </li>
                </ul>
              </div>
            </nav>

    </div>
    </div>
    </header>