<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kunle
 * Date: 23/03/14
 * Time: 23:54
 * To change this template use File | Settings | File Templates.
 */
include('template/header.php');?>

<div class="clearfix"></div>

<div class="support-img">
    <div class="container">
        <div class="big_image_title text-center">
        </div>
        <div class="custom_button text-center">
            <ul>
                <!--<li class="red_btn"> <a href="#">Subscribe Now</a></li>-->
            </ul>
        </div>
    </div>
</div>


<div class="section">
    <div class="container animation-container"><div class="section">
            <div class="container animation-container">
                <div class="title"><h2 class="text-left" style="color: #575790">Support</h2> <span><h5 class="text-left gray"> </h5></span></div>
                <h5 class="content" style="margin-bottom: 25px"><span style="color: #4e7d8f; font-weight: bolder">Bhooce</span> offers comprehensive tech support across platforms, devices and applications for both individuals and businesses. Our goal is to ensure you get the best out of your tech devices and always there whenever any issue arises. Check out our plans <a href="index.php#pricing">here</a></h5>
            <div class="software-box">
                <div class="left-soft">
                    <img alt="" src="include/images/software_img.png">
                </div>
                <div class="right-soft">
                    <h2><a href="sotware.php">Software</a></h2>
                    <p>Bhooce support over 650 applications including business specific application. </p>
                    <ul>
                        <li></li>
                        <li></li>
                        <li></li>
                    </ul>
                </div>
            </div>
            </div>
            </div>
        </div>
    </div>
<?php include('template/footer.php');?>