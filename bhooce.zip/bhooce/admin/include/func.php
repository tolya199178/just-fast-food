<?php
	/* Define common functions for admin panel*/
	/* @author: M Awais */
	/* @created: 13/04/2014 */

	/* get the user detail from user id
		@param: id: (int)
		@return: Object list of user */
	function getUser($id = ''){
		global $DB;

		$USER = $DB -> getResult('user', 'WHERE `id` = "'.$id.'"');
		return $USER[0];
	}

	/* 	Get the configuration from
		@param: ID: (int)
		@return: Object list */
	function amin_config($id) {
		global $DB;

		$JOIN = $DB -> getResult('setting', 'WHERE `id` = "'.$id.'"');
		return $JOIN[0];
	}

	function escape($str = ''){
		return strip_tags(trim($str));
	}

	function JSON_EN($array){
		if(!is_array($array)) return '';

		$newA = array();
		foreach($array as $key => $value) {
			$newA[$key] = escape($value);
		}

		return json_encode($newA);
	}

?>