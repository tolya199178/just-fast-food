<?php

function newPlan($newCon) {

	$RETURN = array();

	try {
		require_once('../include/card/include/lib/Stripe.php');
		require_once('../include/stripe.config.php');
		Stripe::setApiKey(STRIPE_TEST_SK);

		Stripe_Plan::create(array(
		  "amount" => $newCon -> price * 100,
		  "interval" => "month",
		  "name" => $newCon -> title,
		  "currency" => "usd",
		  "id" => $newCon -> title)
		);

		$RETURN['error'] = false;
		$RETURN['msg'] = 'successful';

	} catch (Stripe_CardError $e) {
		// Card was declined.
		$e_json = $e->getJsonBody();
		$err = $e_json['error'];
		$RETURN['error'] = true;
		$RETURN['msg'] = $err['message'];

	} catch (Stripe_ApiConnectionError $e) {
		// Network problem, perhaps try again.

		$RETURN['error'] = true;
		$RETURN['msg'] = "Network problem, perhaps try again.";

	} catch (Stripe_InvalidRequestError $e) {
		// You screwed up in your programming. Shouldn't happen!

		$RETURN['error'] = true;
		$RETURN['msg'] = "You screwed up in your programming. Shouldn't happen!";

	} catch (Stripe_ApiError $e) {
		// Stripe's servers are down!

		$RETURN['error'] = true;
		$RETURN['msg'] = "Stripe's servers are down!";

	} catch (Stripe_CardError $e) {
		// Something else that's not the customer's fault.

		$RETURN['error'] = true;
		$RETURN['msg'] = "Something else that's not the customer's fault.";
	}

	return $RETURN;
}

?>