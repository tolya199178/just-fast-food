<?php

	$user_name = 'admin'; 		// ADMIN USER NAME
	$password = 'admin_123'; 	// ADMIN PASSWORD


	define('ADMINUSER', $user_name);
	define('ADMINPASS', md5($password));
?>