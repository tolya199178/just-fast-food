<?php
	session_start();
	if(!isset($_SESSION['admin']) || !isset($_SESSION['admin']['id'])) {
		header('location:login.php');exit;
	}

	require_once('include/dbclass.php');
	require_once('include/func.php');

?>
<!DOCTYPE html>
<html class="no-js">
<head>
    <meta charset="utf-8">
    <title>SuperAdmin</title>
    <meta name="description" content="Admin Panel">
    <?php include_once('template/header-files.php');?>
</head>
<body>

	<?php include_once('template/header.php');?>
	<div class="row-fluid">
		<div class="container">
			<div class="well">
				<div class="bgw p10">
					<?php

						if(!isset($_GET['page']) || empty($_GET['page'])){
					?>
							<div class="bgw p10">
								<h2>Welcome Admin</h2> <hr/>
								<p>You are allow to create/edit subscription plan, subscription period and users</p>
							</div>
					<?php
						} else {

							$PAGE = $_GET['page'];
							if(!file_exists('template/'.$PAGE.'.php')){
					?>
								<div class="bgw p10">
									<h2>404 PAGE NOT FOUND!</h2>
								</div>
					<?php
							} else {
								include_once('template/'.$PAGE.'.php');
							}
						}
					?>
				</div>
			</div>
		</div>
	</div>
	<!--/row-fluid-->
	<?php include_once('template/footer.php');?>

</body>
</html>
