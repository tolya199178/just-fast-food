<?php
	$TABLE = 'subscription_period';
	if(isset($_POST['SUBMIT'])) {

		$upate = false;
		$data = $_POST;
		if(isset($data['update'])){
			$upate = true;
		}

		$newCon = new stdClass;
		$newCon -> id = ($upate) ? escape($data['id']) : NULL ;
		$newCon -> title = escape($data['title']);
		$newCon -> status = '1';

		if($upate) {
			$DB -> update($TABLE, $newCon, 'id');
		} else {
			$DB -> insert($TABLE, $newCon);
		}

		//header('Location:./?page=all-contest');exit;
	}

	$UPDATE = '';
	if(isset($_GET['id']) && !empty($_GET['id'])) {
		$ID = (int) $_GET['id'];
		$Res = $DB -> getResult($TABLE, "WHERE `id` = '".$ID."'");

		if(!empty($Res)){
			$UPDATE = $Res[0];
		} else {
			header('Location:./?page=error');exit;
		}
	}
?>

<h2><?php if(empty($UPDATE)) { ?> Add New Subscription Period <?php } else { ?> Update Subscription Period <?php } ?></h2> <hr/>
<div class="row-fluid">
	<div class="">
        <form class="form-horizontal" method="post" action="./?page=new-subscription-period" id="new-subscription-form">
            <fieldset>
                <div class="control-group">
                    <label class="control-label" for="title">Title</label>
                    <div class="controls">
                        <input type="text" id="title" name="title" placeholder="Subscription Period Title" class="input-xxlarge" value="<?php echo $UPDATE -> title ?>">
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary" name="SUBMIT">Submit</button>
					<?php
						if(!empty($UPDATE)) {
							echo '<input type="hidden" name="update" value="true"/>';
							echo '<input type="hidden" name="id" value="'.$UPDATE -> id.'"/>';
						}
					?>
                </div>
            </fieldset>
        </form>
    </div>
</div>
