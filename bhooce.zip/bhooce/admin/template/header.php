<div class="navbar navbar-fixed-top">
    <div class="navbar navbar-inverse">
        <div class="navbar-inner">
            <div class="container-fluid">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <span class="brand">SuperAdmin</span>

                <div class="nav-collapse collapse">

                    <ul class="nav">
                        <li class="active">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                               class="icon-home icon-black"></i>
                                Subscription <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="./?page=new-subscription">Create New Subscription</a></li>
                                <li><a href="./?page=new-subscription-period">Create New Subscription Period</a></li>
                            </ul>
						</li>
                    </ul>

                    <ul class="nav pull-right settings">
                        <li><a href="./?page=setting" class="tip icon logout" data-original-title="Settings"
                               data-placement="bottom"><i class="icon-large icon-cog"></i></a></li>
                        <li class="divider-vertical"></li>
                        <li><a href="./signout.php" class="tip icon logout" data-original-title="Logout" data-placement="bottom"><i
                           class="icon-large icon-off"></i></a></li>
                    </ul>

                    <ul class="nav pull-right settings">
                        <li class="divider-vertical"></li>
                    </ul>

                    <p class="navbar-text pull-right">
                        Welcome <strong>Admin</strong>
                    </p>
                </div>
                <!--/.nav-collapse -->
            </div>
        </div>
    </div>
</div>