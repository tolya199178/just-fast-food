<hr>
<footer align="center">
    <p>Copyright &copy; 2014 <strong><a href="http://hqwebsolution.com" target="_blank">HQ Web Solution</a></strong></p>
</footer>