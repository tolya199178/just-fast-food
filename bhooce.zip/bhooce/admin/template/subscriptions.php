<?php
	if(isset($_GET['delete']) && isset($_GET['id']) && $_GET['id'] != "") {
		$id = (int) $_GET['id'];
		$DB -> delete('contest_detail', 'id' , $id);
		header('Location:./?page=all-contest');exit;
	}

	$ALLCONTEST = $DB -> getResult('contest_detail', 'ORDER BY `id` DESC ');
?>

<h2>All Contests</h2> <hr/>
<div class="row-fluid">
	<table class="table bordered-table table-striped table-hover ">
		<thead>
		<tr>
			<th>#</th>
			<th>Name</th>
			<th>URL</th>
			<th>Detail</th>
			<th>Live</th>
			<th>Modified</th>
			<th>Action</th>
			<th width="113">Settings</th>
		</tr>
		</thead>
		<tbody>
		<?php
			foreach($ALLCONTEST as $value) {
				$link = './?page=contest-result&id='.$value -> id;
		?>
			<tr class="<?php echo ($value -> live == 'Yes') ? 'info tip' : '' ?>" data-original-title="Live Contest">
				<td><a href="<?php echo $link; ?>"><?php echo $value -> id ?></a></td>
				<td><a href="<?php echo $link; ?>"><?php echo $value -> name ?></a></td>
				<td><?php echo $value -> url ?></td>
				<td><?php echo $value -> details ?></td>
				<td><?php echo $value -> live ?></td>
				<td><?php echo $value -> date_added ?></td>
				<td class="tabel-action">
					<a href="./?page=new-contest&id=<?php echo $value -> id; ?>"><i class="icon-pencil icon"></i></a>
					<a href="javascript:delete_con(<?php echo $value -> id; ?>);"><i class="icon-trash icon"></i></a>
				</td>
				<td>
					<a href="./?page=setting&id=<?php echo $value -> id; ?>" class="btn btn-info">Go to Settings</a>
				</td>
			</tr>
		<?php }
			if(empty($ALLCONTEST)) {
		?>
			<tr>
				<td colspan="7">No Result Found</td>
			</tr>
		<?php } ?>
		</tbody>
	</table>

	<script type="text/javascript">

		function delete_con(id){
			var c = confirm('Confirm contest delete ?');
			if(c == true) {
				window.location.href = './?page=all-contest&delete=true&id='+id;
			}
		}
	</script>
</div>
