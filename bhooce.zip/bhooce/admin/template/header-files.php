<meta name="viewport" content="width=device-width">

<link href='http://fonts.googleapis.com/css?family=Gudea' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-responsive.min.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/main.css">

<script src="js/vendor/jquery-1.8.3.min.js"></script>
<script src="js/vendor/bootstrap.min.js"></script>
<script src="js/vendor/dateTable.js"></script>
<script src="js/template.js"></script>
<script src="js/jquery.validate.min.js"></script>