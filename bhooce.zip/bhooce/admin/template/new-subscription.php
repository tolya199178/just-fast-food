<?php



	$TABLE = 'subscription';
	$ERROR = false;
	if(isset($_POST['SUBMIT'])) {

		$upate = false;
		$data = $_POST;
		if(isset($data['update'])){
			$upate = true;
		}

		$newCon = new stdClass;
		$newCon -> id = ($upate) ? escape($data['id']) : NULL ;
		$newCon -> title = escape($data['title']);
		$newCon -> price = escape($data['price']);
		$newCon -> currency = 'USD';
		$newCon -> period_id = escape($data['period_id']);
		$newCon -> description = JSON_EN($data['description']);
		$newCon -> status = '1';

		require_once('include/stripe-subs.php');

		if($upate) {
			$DB -> update($TABLE, $newCon, 'id');
		} else {

			$return = newPlan($newCon);
			if(!$return['error']) {
				$DB -> insert($TABLE, $newCon);
				echo 'Successful';
			} else {
				$ERROR = true;
				echo $return['msg'];
			}
		}

		//header('Location:./?page=all-contest');exit;
	}

	$UPDATE = '';
	if(isset($_GET['id']) && !empty($_GET['id'])) {
		$ID = (int) $_GET['id'];
		$Res = $DB -> getResult($TABLE, "WHERE `id` = '".$ID."'");

		if(!empty($Res)){
			$UPDATE = $Res[0];
		} else {
			header('Location:./?page=error');exit;
		}
	}
?>

<h2><?php if(empty($UPDATE)) { ?> Add New Subscription <?php } else { ?> Update Subscription<?php } ?></h2> <hr/>
<div class="row-fluid">
	<div class="">
        <form class="form-horizontal" method="post" action="./?page=new-subscription" id="new-subscription-form">
            <fieldset>
                <div class="control-group">
                    <label class="control-label" for="title">Title</label>
                    <div class="controls">
                        <input type="text" id="title" name="title" placeholder="Subscription Title" class="input-xxlarge" value="<?php echo $UPDATE -> title ?>">
                    </div>
                </div>
				<div class="control-group">
                    <label class="control-label" for="price">Price(USD)</label>
                    <div class="controls">
                        <input type="text" id="price" name="price" placeholder="Subscription Price" class="input-small" value="<?php echo $UPDATE -> price ?>">
                    </div>
                </div>
				<div class="control-group">
                    <label class="control-label" for="period_id">Period</label>
                    <div class="controls">
                        <select name="period_id" id="period_id" class="input-large">
							<?php
								$Periods = $DB -> getResult('subscription_period', "WHERE `status` = '1' ");
								foreach($Periods as $period) {
									echo '<option value="'.$period -> id.'">'.$period -> title.'</option>';
								}
							?>
						</select>
                    </div>
                </div>
				<div class="control-group">
                    <label class="control-label" for="title">Description</label>
                    <div class="controls" id="add-new-wrap">
						<?php
							if(!empty($UPDATE)) {
								$descriptions = json_decode($UPDATE -> description);
								foreach($descriptions as $key => $description) {
									if($description == '') continue;
						?>
									<div class="control-group" id="CountD_<?php echo '_'.$key ?>">
										<input type="text" id="description" name="description[]" placeholder="Description" class="input-xxlarge" value="<?php echo $description ?>">
										<a href="javascript:minusD('<?php echo '_'.$key ?>')" class="tip icon-minus" data-placement="right" data-original-title="Delete"></a>
									</div>
						<?php
								}
							}
						?>
                        <div class="control-group">
							<input type="text" id="description" name="description[]" placeholder="Description" class="input-xxlarge" value="">
							<a href="javascript:addD()" id="addNewDes" class="tip icon-plus" data-placement="right" data-original-title="Add New Description"></a>
						</div>
					</div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary" name="SUBMIT">Submit</button>
					<?php
						if(!empty($UPDATE)) {
							echo '<input type="hidden" name="update" value="true"/>';
							echo '<input type="hidden" name="id" value="'.$UPDATE -> id.'"/>';
						}
					?>
                </div>
            </fieldset>
        </form>
		<script type="text/javascript">
			var Count = 0;
			function addD() {
				var HTML = '<div class="row-fluid control-group" id="CountD_'+Count+'">';
					HTML +=		'<input type="text" id="description" name="description[]" placeholder="Description" class="input-xxlarge" value="">';
					HTML +=		' <a href="javascript:minusD('+Count+')" class="tip icon-minus"  data-placement="right" data-original-title="Delete"></a>';
					HTML +=	'</div>';
				$('#add-new-wrap').append(HTML);
				Count ++;
			}

			function minusD(id) {
				$('#CountD_'+id).remove();
			}
		</script>
    </div>
</div>
