<?php
	session_start();

	$data = $_POST;
	$session = $_SESSION['SESSION'];

//var_dump($_COOKIE['subType']);
	/* echo '<pre>';
	print_r($_SESSION);
	echo '</pre>'; */
// Check for a form submission:

if(isset($data['SESSION']) && $data['SESSION'] == $session) {

require_once('../../admin/include/dbclass.php');
require_once('../../include/class.subs.php');

$id = (int) $data['subId'];

$obj = new subscription;
$subscription = $obj -> getSubscription($id);
$subscription = $subscription[0];
if(empty($subscription)) {
	echo 'Error in subscription plan';
	exit;
}

	// Stores errors:
	$errors = array();

	// Need a payment token:
	if (isset($data['stripeToken'])) {

		$token = $data['stripeToken'];

		// Check for a duplicate submission, just in case:
		// Uses sessions, you could use a cookie instead.
		if (isset($_SESSION['token']) && ($_SESSION['token'] == $token)) {
			$errors['token'] = 'You have apparently resubmitted the form. Please do not do that.';
		} else { // New submission.
			$_SESSION['token'] = $token;
		}

	} else {
		$errors['token'] = 'The order cannot be processed. Please try Again';
	}

	if (isset($errors) && !empty($errors) && is_array($errors)) {
		echo '<p class="alert alert-danger">'.$errors['token'].'</p>';
		die();
	}

	// Set the order amount somehow:
	$amount = $subscription -> price * 100;
	$description = 'An Order of Amount '.$amount;

	// If no errors, process the order:
	if (empty($errors)) {

		// create the charge on Stripe's servers - this will charge the user's card
		try {

			// Include the Stripe library:
			require_once('include/lib/Stripe.php');
			require_once('../stripe.config.php');

			// set your secret key: remember to change this to your live secret key in production
			// see your keys here https://manage.stripe.com/account
			Stripe::setApiKey(STRIPE_TEST_SK);

            //Create subscription
			$customer = Stripe_Customer::create(array(
			  "card" => $token,
			  "plan" => $subscription -> subtitle,
			  "email" => strip_tags(trim($data['email']))
			));

			// WHEN NOT RECURRING ------ Charge the order:
			/* $charge = Stripe_Charge::create(array(
				"amount" => $amount, // amount in cents, again
				"currency" => "gbp",
				"card" => $token
				)
			); */

			// Check that it was paid:
			/* if ($charge->paid === true) {

				// Store the order in the database.
				// Send the email.
				echo '<div class="alert alert-success">';
				echo 'Payment done successful!'.$charge->id;
				echo '</div>';

			} else { // Charge was not paid!
				echo  '<p class="alert alert-danger">Payment System Error!<br/>Your payment could NOT be processed (i.e., you have not been charged) because the payment system rejected the transaction. You can try again or use another card.</p>';

            } */

			echo '<div class="alert alert-success">';
			echo 'Payment done successful!';
			echo '</div>';
			//print_r($customer);

		} catch (Stripe_CardError $e) {
		    // Card was declined.
			$e_json = $e->getJsonBody();
			$err = $e_json['error'];
			echo '<p class="alert alert-danger">'.$err['message'].'</p>';
			die();
            return;

		} catch (Stripe_ApiConnectionError $e) {
		    // Network problem, perhaps try again.

			echo '<p class="alert alert-danger">Network problem, perhaps try again</p>';
			die();

		} catch (Stripe_InvalidRequestError $e) {
		    // You screwed up in your programming. Shouldn't happen!

			echo '<p class="alert alert-danger">You screwed up.</p>';
			die();

		} catch (Stripe_ApiError $e) {
		    // Stripe's servers are down!

			echo '<p class="alert alert-danger">Server are down!.</p>';
			die();

		} catch (Stripe_CardError $e) {
		    // Something else that's not the customer's fault.

			echo '<p class="alert alert-danger">Something else that\'s not the customer\'s fault..</p>';
			die();
		}

	} // A user form submission error occurred, handled below.

} else {
	echo '<p class="alert alert-danger">Error! Session Not Valid</p>';
	die();
}

unset($_SESSION['SESSION']);
?>