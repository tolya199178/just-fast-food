<?php

	class subscription{

		function getSubscription($id = ''){
			global $DB;

			$where = ' WHERE `a`.`period_id` = `b`.`id` AND `a`.`status` = 1 ';
			$id = (int) $id;

			if($id != '') {
				$where .= " AND `a`.`id` = '".$id."'";
			}

			$col = '`a`.*, `b`.*, `a`.`id` AS subid, `a`.`title` AS subtitle, `b`.`title` AS ptitle';
			$table = '`subscription` AS `a`, `subscription_period` AS `b`';
			$data = $DB -> getResult($table, $where, $col);

			return $data;
		}
	}