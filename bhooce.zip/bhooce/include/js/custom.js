
/*client testimonial carousel*/
	
 jQuery(document).ready(function() {

      var owl = $("#owl-demo");

     
 owl.owlCarousel({
      items : 1, //10 items above 1000px browser width
	  autoPlay: true,
	 	pagination : true,
    	paginationNumbers: false,
		 itemsDesktop : [1199,1],
    itemsDesktopSmall : [980,1],
    itemsTablet: [768,1],
    itemsMobile : [479,1]
     
  });
      // Custom Navigation Events
      $(".next").click(function(){
        owl.trigger('owl.next');
      })
      $(".prev").click(function(){
        owl.trigger('owl.prev');
      })
      $(".play").click(function(){
        owl.trigger('owl.play',1000);
      })
      $(".stop").click(function(){
        owl.trigger('owl.stop');
      })


    });
	
	/*CUSTOM ON SCROLL ANIMATIONS*/
		$(window).scroll(function() {
			$('#object').each(function(){
			var imagePos = $(this).offset().top;
			
			var topOfWindow = $(window).scrollTop();
				if (imagePos < topOfWindow+800) {
					$(this).addClass("slideUp");
				}
			});


			

		});
		
			$(window).scroll(function() {
			$('#object4').each(function(){
			var imagePos = $(this).offset().top;
			
			var topOfWindow = $(window).scrollTop();
				if (imagePos < topOfWindow+800) {
					$(this).addClass("slideRight");
				}
			});


			

		});
		
		

		$(window).scroll(function() {
			$('#snapshot').each(function(){
			var imagePos = $(this).offset().top;
			
			var topOfWindow = $(window).scrollTop();
				if (imagePos < topOfWindow+800) {
					$(this).addClass("slideLeft");
				}
			});
			
			
			$('#snapshot2').each(function(){
			var imagePos = $(this).offset().top;
			
			var topOfWindow = $(window).scrollTop();
				if (imagePos < topOfWindow+2200) {
					$(this).addClass("slideRight");
				}
			});
			
			$('#object2').each(function(){
			var imagePos = $(this).offset().top;
			
			var topOfWindow = $(window).scrollTop();
				if (imagePos < topOfWindow+800) {
					$(this).addClass("fadeIn");
				}
			});
			
			
        $('#devices').each(function(){
			var imagePos = $(this).offset().top;
			
			var topOfWindow = $(window).scrollTop();
				if (imagePos < topOfWindow+800) {
					$(this).addClass("pullUp");
				}
			});


		});

		
		$(window).scroll(function() {
			$('#tweet').each(function(){
			var imagePos = $(this).offset().top;
			
			var topOfWindow = $(window).scrollTop();
				if (imagePos < topOfWindow+800) {
					$(this).addClass("pulse");
				}
			});
        });




            $(document).ready(function(){
                $('#show').mouseover(function(){
                    $(this).tooltip('show').attr('data-animation', true);
                });
            });

$(document).ready(function(){
    $('.form-control').each(function() {
        $(this).mouseover(function(){
            $(this).tooltip('show').attr('data-animation', true);
        });
    });

});


$(document).ready(function(){
    $('.device-list').mouseover(function(){
        $(this).tooltip('show').attr('data-animation', true);
    });
});

$(document).ready(function(){
    $('#show').click(function() {
        $('#entsol').slideToggle("slow");
        $("#show span").toggleClass('glyphicon-plus glyphicon-minus');


    });
});

$(document).ready(function(){
        $('.choose').textillate({
            in:  {
                shuffle: false,
                sync:true
            },

                out: {
                    effect: 'fadeOutRightBig',
                    delayScale: 1.5,
                    delay: 50,
                    sync: false,
                    shuffle: false,
                    reverse: false
            },
            loop:true
        });

});


// Animate text
$(document).ready(function(){
    $('.device-list').textillate({
        in:  {
            shuffle: false,
            sync:true
        },

        out: {
            effect: 'fadeOutRightBig',
            delayScale: 1.5,
            delay: 50,
            sync: false,
            shuffle: false,
            reverse: false
        },
        loop:true
    });

});

// Count up variables


// set countUp options
var options = {
    useEasing : true, // toggle easing
    useGrouping : true, // 1,000,000 vs 1000000
    separator : ',', // character to use as a separator
    decimal : '.' // character to use as a decimal
}
var useOnComplete = false;
var useEasing = true;
var useGrouping = true;

// create instance

$(window).load(function(){
    $(document).ready(function(){

        var demo = new countUp('myTargetElement', 94.02, 210147.62, 0, 6.5, options);
        var demo2 = new countUp('myTargetElement2', 0.62, 10, 0, 9.5, options);
        $(document).scroll(function() {

            var top = $(document).scrollTop();

            if (top > 600) {
                demo.start();
                demo2.start();

            }


        });
    });


    // for demo:
    function swapValues() {
        var oldStartVal = document.getElementById("startVal").value;
        var oldEndVal = document.getElementById("endVal").value;
        document.getElementById("startVal").value = oldEndVal;
        document.getElementById("endVal").value = oldStartVal;
        updateCodeVisualizer();
    }
    var code;
    function createCountUp() {

        var startVal = document.getElementById("startVal").value;
        alert (startVal);
        startVal = Number(startVal.replace(',','').replace(' ',''));
        var endVal = document.getElementById("endVal").value;
        endVal = Number(endVal.replace(',','').replace(' ',''));
        var decimals = document.getElementById("decimals").value;
        var duration = document.getElementById("duration").value;

        options = {
            useEasing : useEasing,
            useGrouping : useGrouping,
            separator : document.getElementById("separator").value,
            decimal : document.getElementById("decimal").value
        }

        // you don't have to create a new instance of countUp every time you start an animation,
        // but I do here in case user changes values in demo.

    }

});

// Create progress bar for form subscription

$(document).ready(function(){
    //jQuery time
    var current_fs, next_fs, previous_fs; //fieldsets
    var left, opacity, scale; //fieldset properties which we will animate
    var animating; //flag to prevent quick multi-click glitches

    $('.next').click(function(){

   if ($('.form-container #signup-form input[type="text"], input[name="email"],input[name="cardccv"], input[name="address"], .select').val() != '') {

           if(animating) return false;
           animating = true;

           current_fs = $(this).parent();
           next_fs = $(this).parent().next();

           //activate next step on progressbar using the index of next_fs
           $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

           //show the next fieldset
         next_fs.show();

           //hide the current fieldset with style
           current_fs.animate({opacity: 0}, {
               step: function(now, mx) {
                   //as the opacity of current_fs reduces to 0 - stored in "now"
                   //1. scale current_fs down to 80%
                   scale = 1 - (1 - now) * 0.2;
                   //2. bring next_fs from the right(50%)
                   left = (now * 50)+"%";
                   //3. increase opacity of next_fs to 1 as it moves in
                   opacity = 1 - now;
                   current_fs.css({'transform': 'scale('+scale+')'});
                   next_fs.css({'left': left, 'opacity': opacity});
               },
               duration: 800,
               complete: function(){
                   current_fs.hide();
                   animating = false;
               },
               //this comes from the custom easing plugin
               easing: 'easeInOutBack'
           });
     }
       });


       $(".submit").click(function(){
           return false;
       });

});

//Menu url
$(document).ready(function(){
    var url = window.location.href.substr(window.location.href.lastIndexOf("/") + 1);

    $('[href$="'+url+'"]').parent().removeClass("active").addClass("active");
});


// Hide the rightSection div once the 'Place Order' button is clicked

$(document).ready(function(){
   $('.form-container #signup-form input[name="addUser"]').click(function(){
       $('.rightSection').hide();
   });
});


/* Add 'City' div when a user clicks in the 'address' textbox

    $(document).ready(function(){
        var inputField = $('.form-container #signup-form input[name="address"]');
        var cityField =  $('.form-container #signup-form input[name="city"]');
        cityField.hide();
        $(inputField).live('focus', function(event) {
            cityField.show();
        });
    });
*/

// Format Credit card number
$(document).ready(function(){
    $('.form-container #signup-form input[type="submit"]').prop("disabled", true); //disable the submit button
    $('.form-container #signup-form input.credit_card_number').formance("format_credit_card_number")
        .on('keyup change blur', function(event){
            if($(this).formance('validate_credit_card_number'))
                $("input[type='submit']").prop("disabled", false); //enable the submit button if valid phone number is entered
            else
                $("input[type='submit']").prop("disabled", true); //disable the submit button if invalid phone number
        });
});

// Format Credit card cvc
$(document).ready(function(){
    $('.form-container #signup-form input[type="submit"]').prop("disabled", true); //disable the submit button
    $('.form-container #signup-form input.credit_card_cvc').formance("format_credit_card_cvc")
        .on('keyup change blur', function(event){
            if($(this).formance('validate_credit_card_cvc'))
                $("input[type='submit']").prop("disabled", false); //enable the submit button if valid phone number is entered
            else
                $("input[type='submit']").prop("disabled", true); //disable the submit button if invalid phone number
        });
});

$(document).ready(function(){
    $(".section_top").stickyNavbar({
        activeClass: "active",        // Class to be added to highlight nav elements
        sectionSelector: "scrollto",  // Class of the section that is interconnected with nav links
        navOffset: 0,                 // Offset from the default position of this() (nav container)
        animDuration: 250,            // Duration of jQuery animation
        startAt: 0,                   // Stick the menu at XXXpx from the top of the this() (nav container)
        easing: "linear",             // Easing type if jqueryEffects = true, use jQuery Easing plugin to extend easing types - gsgd.co.uk/sandbox/jquery/easing
        animateCSS: true,             // AnimateCSS effect on/off
        animateCSSRepeat: false,      // Repeat animation everytime user scrolls
        bottomAnimation: false,       // CSS animation on/off in case we hit the bottom of the page
        cssAnimation: "fadeInDown",   // AnimateCSS class that will be added to selector
        jqueryEffects: false,         // jQuery animation on/off
        jqueryAnim: "slideDown",      // jQuery animation type: fadeIn, show or slideDown
        selector: "a",                // Selector to which activeClass will be added, either "a" or "li"
        mobile: false
    });

});

$(document).ready(function(){
   $('.form-container #signup-form input[type="submit"]').click(function(){
       var myInt=setInterval(function(){ clearInterval(myInt);
           var c;
           c=localStorage.getItem("token1");
           if (c!= null && c =='') {
               $('.form-container #signup-form .confirmation').show();
           } else {
               $('.form-container #signup-form .confirmation').hide();
           }
           alert(c);
       },5000);
   }) ;
});