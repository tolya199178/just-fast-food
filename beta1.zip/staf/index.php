<?php
echo("<script>window.location='import.php'</script>");
?>
