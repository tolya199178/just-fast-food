<?php
class EmailException 
{
	function __construct($message = FALSE, $code = FALSE)
	{
//		$this->message = $message;
//		$this->code = $code;
	}
}

?>
