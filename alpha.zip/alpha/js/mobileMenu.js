(function (e) {
    e.fn.mobileMenu = function (n) {
    }
})(jQuery)