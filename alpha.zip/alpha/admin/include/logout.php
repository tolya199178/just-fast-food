<?php
	session_start();
	unset($_SESSION['ADMIN']);
	unset($_SESSION['ADMIN_PARTNER']);
	unset($_SESSION['access_key']);
?>