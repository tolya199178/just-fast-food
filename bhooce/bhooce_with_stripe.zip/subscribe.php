<?php
/**
 * Created by PhpStorm.
 * User: Kunle
 * Date: 27/03/14
 * Time: 09:49
 */
session_start();
$_SESSION['SESSION'] = md5(time().rand());

global $geoplugin;
include('template/header.php');
// Instantiate
/* $result = new Database();
// Connect into database
$tableName = $result->connect_db();
$userTable = array_shift($tableName[2]);
*/

require_once('include/stripe.config.php');

?>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script type="text/javascript">

	function submitHandler(){

		$('#pp-dialog').modal();

		var ccNum = $('#card_no').val().trim(), cvcNum = $('#csc').val().trim(), expMonth = $('#MM').val().trim(), expYear = $('#YYYY').val().trim(), Name = $('#f_name').val().trim() + ' ' + $('#l_name').val().trim();

		if($('#N_Addr').val() != ''){
			Addr = $('#N_Addr').val();
		}
		if($('#N_Postcode').val() != ''){
			Zip = $('#N_Postcode').val();
		}

		Stripe.setPublishableKey("<?php echo STRIPE_TEST_PK; ?>");
		Stripe.createToken({
			number: ccNum,
			cvc: cvcNum,
			exp_month: expMonth,
			exp_year: expYear,
			name : Name,
			address_line1 : Addr,
			address_zip : Zip
		}, stripeResponseHandler);
	}

	function stripeResponseHandler(status, response) {
		var result = $('#pp-dialog .modal-content .result');
		if (response.error) {
			html = '<div class="alert alert-danger fade in"><h4>Error!</h4><p>'+response.error.message+'</p></div>';
			result.html(html);
		} else { // No errors, submit the form:
		  var f = $("#signup-form");
		  // Token contains id, last4, and card type:
		  var token = response['id'];
		  // Insert the token into the form so it gets submitted to the server
		  f.append("<input type='hidden' name='stripeToken' value='" + token + "' />");
		  $('#SESSION').val('<?php echo $_SESSION['SESSION']; ?>');
		  // Submit the form:
		  //f.get(0).submit();

		  $.ajax({
			  type: "POST",
			  url: "include/card/process.php",
			  data: f.serialize(),
			}).done(function(msg) {
				result.html(msg);
			});
		}
	}

</script>

<div class="modal fade" id="pp-dialog" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
				<h4 class="modal-title" id="myLargeModalLabel">Card Processing</h4>
			</div>
			<div class="modal-body result">
				<p style="text-align:center">
					Please wait your card is processing. <br/>
					<img src="include/images/ajax-loader.gif" alt=""/>
				</p>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>
    <hr class="sep1">
    <!--Slider -->
    <div class="big_image0">
        <div class="form-container" style="width: 90%">
            <div class="container">
				<ul id="progressbar">
					<li class="active">Personal Information</li>
					<li>Payment</li>
					<li>Confirmation</li>
				</ul>
                <form id="signup-form" method="post" action="">
                    <fieldset>
                        <h2 class="text-left" style="color: #575790">Please enter your information below</h2> <span><h5 class="text-left gray"> </h5></span>
                            <input id="f_name" class="" type="text" placeholder="Enter your first name" name="firstName" data-parsley-range="[4, 20]" data-parsley-group="block1" data-placement="top" data-toggle="tooltip" title="Please enter your first name." required autofocus autocomplete="off"/>
                            <input id="l_name" class="" type="text" placeholder="Enter your last name" name="lastName" data-parsley-range="[4, 20]" data-parsley-group="block1" data-placement="top"  data-toggle="tooltip" title="Please enter your last name" required autocomplete="off"/>
                            <input id="mce-PASSWORD" class="" type="email" data-parsley-trigger="change" placeholder="Enter your email" name="email" data-placement="top" required data-toggle="tooltip" title="We will send your confirmation to this email." autocomplete="off"/>
                            <input id="N_Addr" class="" type="text" data-parsley-trigger="change" placeholder="Enter your address" name="address" data-placement="top" required data-toggle="tooltip" title="Please enter your address"  autocomplete="off"/>
                            <input id="mce-PASSWORD" class="" type="text" data-parsley-trigger="change" placeholder="City" name="city" data-placement="top" required data-toggle="tooltip" title="Please enter your city address"  autocomplete="off"/>
                            <input id="N_Postcode" class="" type="text" data-parsley-trigger="change" placeholder="Enter your <?php if($geoplugin->countryCode == "GB") { echo 'postcode';} else { echo 'zipcode';};?>" name="password" data-placement="top" required data-toggle="tooltip" title="For example, SE13 1FG" autocomplete="off"/>
                        <input type="button" name="next" id="next" class="next action-button" value="Next" />
                    </fieldset>
                    <fieldset>
                        <h2 class="text-left" style="color: #575790">Please enter your payment information</h2> <span><h5 class="text-left gray"> </h5></span>
                        <select name="select" id="select" class="select" required="required">
                            <option value="">Select Card Type</option>
                            <option value="visa">Visa</option>
                            <option value="master">Mastercard </option>
                            <option value="debt">Visa Debit </option>
                            <option value="dis">Discover </option>
                            <option value="exp">American Express </option>
                        </select>
                        <input id="card_no" class="form-control" type="pwd" placeholder="Enter your card number" name="cardnumber" data-placement="right" required="required" data-toggle="tooltip" title="e.g 4657488599687784" autocomplete="off" maxlength="16">
                        <div >
                            <select name="month" id="MM" class="month" required="required">
                                <option value="">Expiry Month</option>
                                <?php
                                $month = array('01'=>'Jan', '02'=>'Feb' , '03'=>'Mar' ,'04'=>'Apr' ,'05'=>'May' , '06'=>'Jun' , '07'=>'Jul' , '08'=>'Aug' , '09'=>'Sep' , '10'=>'Oct' , '11'=>'Nov' ,'12'=>'Dec');
								foreach($month as $k => $m) {
                                    echo '<option value="'.$k.'">'.$k.' ('.$m.') </option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div >
                            <select name="year" id="YYYY" class="year" required="r">
                                <option value="">Expiry Year</option>
                                <?php
                                $now = date('Y');
                                for($i = $now ; $i < $now + 11 ; $i ++) {
                                    $y = substr($i, strlen($i)-2, 2);
                                    echo '<option value="'.$y.'">'.$i.'</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <input id="csc" class="form-control" type="number" placeholder="CVV" name="cardcvv" data-placement="right" required data-toggle="tooltip" autocomplete="off">
                        <input id="mce-PASSWORD" class="form-control" type="text" placeholder="Enter your phone number" name="phoneno" data-placement="right" required data-toggle="tooltip" autocomplete="off">
                         <span style="float: left; clear: both">
                           <input id="mce-check" class="fom-control" type="checkbox" value="terms">
                        </span>
                        <span class="agreeTerms">
                            I agree with the
                                <a target="_blank" href="terms-condition.html"> terms and conditions</a>
                        </span>
                        <input type="button" onclick="submitHandler()" name="addUser" class="next action-button" value="Place Order" />
						<input type="hidden" name="SESSION" id="SESSION" value=""/>
				   </fieldset>
					<fieldset>
						<h2 class="text-left" style="color: #575790">Confirmation</h2> <span><h5 class="text-left gray"> </h5></span>
						<span>Thank you for subscribing. Please check your email for confirmation.</span>
					</fieldset>
                </form>

            </div>
			<div class="rightSection">
					<div class="headDisplay">
						<h5>
							FOR BILLING ISSUES
							<br>
							OR CUSTOMER COMPLAINTS
							<br>
							<span>Call</span>
							<strong>1 866 914 9049</strong>
						</h5>
						<h4 style="float: right; margin-top: -4em"><?php if ($_GET['h'] == 1 && ($_GET['subType'] == 'basic')) { echo $geoplugin->convert(19.99, 2, true); } else if (($_GET['h'] == 1) && ($_GET['subType'] == 'prem')){ echo $geoplugin->convert(80.00, 2, true);; }else { echo $geoplugin->convert(49.00, 2, true);}?></h4>
					</div>
					<div class="price" id="bottomSection">
						<?php if ($_GET['h']== 1 && ($_GET['subType'] == 'basic')) { ?>
						<div class="small_title">
							<h3><b>Remote Tech Support</b></h3>
						</div>
					   <ul class="list-unstyled">
						   <li class="basic float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px; color: green"></span>Stop Crashes & Blue Screens</li>
						   <li class="basic float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Overcome Slow Start-Up & Shut-Downs</li>
						   <li class="basic float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>System Tune-up/Repair/Green PC</li>
						   <li class="basic float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Remove Unwanted Pop-Ups & Software Error</li>
						   <li class="basic float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Virus, Spyware, Adware/Malware Removal</li>
						   <li class="basic float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Program install/Uninstall</li>
						   <li class="basic float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Wireless Connectivity Setup & Repair</li>
						   <li class="basic float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>One PC, Smartphone & Printer Supported</li>
						   <li class="basic float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Unlimited live chat</li>
					   </ul>
						<?php } else if ($_GET['h']== 1 && ($_GET['subType'] == 'prem')) {?>
						<div class="small_title">
							<h3><b>Advance & On-Site Support</b></h3>
						</div>
						<ul class="list-unstyled">
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px; color: green"></span>Onsite resolution at your Office</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>VMWare/Workstation scheduled maintenance</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Advance Backup Solutions</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Disaster Recovery and Fail Over solutions</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Router and Firewall Configuration</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Server Maintenance Services</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Wireless Connectivity Setup & Repair</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Network printer configuration & Installation</li>
						</ul>
						<?php } else if ($_GET['h']== 1 && ($_GET['subType'] == 'oneoff')) { ?>
						<div class="small_title">
							<h3><b>One-Off Technical Support</b></h3>
						</div>
						<ul class="list-unstyled" id="oneOffSub">
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px; color: green"></span>Adware/Spyware clean up</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Virus removal and protection verification</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Antivirus installation and configuration</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Hard drive defragmentaion</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Startup optimization & Tune Ups</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Program install/Uninstall</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Wireless Connectivity Setup & Repair</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>One PC, Smartphone & Printer Supported</li>
							<li class="premium float-shadow"><span class="glyphicon glyphicon-ok" style="margin-right: 5px ; color: green"></span>Temporary files cleanup</li>
						</ul>
					  <?php } else { header('location: index.php');} ?>
					</div>
				</div>
				<div class="clearfix"></div>
        </div>
        </div>
<div class="clearfix"></div>
<?php include('template/footer.php');?>