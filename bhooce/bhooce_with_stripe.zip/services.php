<?php include('template/header.php');?>

<div class="clearfix"></div>
<!--Slider -->

<div class="big_image">

<div class="container">

<div class="big_image_title text-center"><h1>24/7 Availability to serve and troubleshoot computer issues</h1> <span>omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet </span></div>

<div class="custom_button text-center">
          <ul>
            
            <li class="red_btn"> <a href="#">Subscribe Now</a></li>
          </ul>
        </div>

</div>


</div>

<div class="section">
<div class="container">
<ul class="breadcrumb">
  <li><a href="index.php">Home</a> </li>
  <li class="active"><a href="services.php">Services</a> </li>
  
</ul>

</div>

</div>




<div class="section">
<div class="container animation-container">

<div class="title"><h2 class="text-center">Our Services </h2> <span><h5 class="text-center gray">Sed ut perspiciatis unde omnis iste natus<br> error sit voluptatem accusantium 
doloremque laudantium, totam </h5></span></div>

<div class="services" id="object">
<div class="services_item">
<a href="diagnosis.php">
<ul>
<li><img src="include/images/repair.png"></li>
<li><h3>Diagnosis & Repair </h3></li>
<li><p>The one stop comprehensive diagnostic & repair station for your computer and connected devices. we can fix anything ! - </p></li>

<li><span class="glyphicon glyphicon-chevron-down red"></span></li>
</ul>
</a>
</div>

<div class="services_item">
<a href="">
<ul>
<li><img src="include/images/installation.png"></li>
<li><h3>Setup & Installation </h3></li>
<li><p>The one stop comprehensive diagnostic & repair station for your computer and connected devices. we can fix anything ! - </p></li>

<li><span class="glyphicon glyphicon-chevron-down red"></span></li>
</ul>
</a>
</div>
<div class="services_item">
<a href="">
<ul>
<li><img src="include/images/maintenance.png"></li>
<li><h3>Maintenance Services </h3></li>
<li><p>The one stop comprehensive diagnostic & repair station for your computer and connected devices. we can fix anything ! - </p></li>

<li><span class="glyphicon glyphicon-chevron-down red"></span></li>
</ul>
</a>
</div>


</div>

</div>

</div>




<div class="section">
<div class="container">
<div class="title"><h2 class="text-center">Call <span class="red">1 800 237 3901</span></h2> 
<h4 class="text-center">for Instant Tech Support NOW!</h4></div>
</div>


</div>


<!-- Modal -->

<div class="solutions">
<ul>
<li id="show" title="Expand to select solutions"><span class="glyphicon glyphicon-plus"></span></li>

</ul>
</div>

<div class="section" id="entsol">
<div class="container">

<div class="services">
<div class="services_item">
<a href="">
<ul>
<li><img src="include/images/home.png"></li>
<li><h3>Home Solutions </h3></li>


</ul>
</a>
</div>

<div class="services_item">
<a href="">
<ul>
<li><img src="include/images/business.png"></li>
<li><h3>Business Solutions </h3></li>

</ul>
</a>
</div>
<div class="services_item">
<a href="">
<ul>
<li><img src="include/images/enterprize.png"></li>
<li><h3>Enterprize Solutions</h3></li>

</ul>
</a>
</div>


</div>
</div>
</div>




<div class="special_offer">
<div class="container">

<div class="sec_left col-lg-9">
<div class="title special"><h3 class="white">2 Weeks Free Trail</h3></div>
<div class="p2 white special">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos</div>
</div>
<div class="custom_button mrg">
          <ul>
            <li class="yellow_btn"> <a href="#">2 weeks FREE Trial </a></li>

          </ul>
        </div>
</div>
</div>

<div class="section_packages">
<div class="container animation-container" id="object4">
<div class="title"><h2 class="white shadow text-center">Just select the service that fits your needs<br>
and leave the rest to us. </h2></div>


<div class="package">
<ul>
<li class="p_title">Digital Home Advanced</li>
<li class="price">$29.99 <span>Per Month</span></li>

<li class="features">Costs just $29.99 per month plus 
a one-time setup fee of $60</li>

<li class="features">Costs just $29.99 per month plus 
a one-time setup fee of $60</li>

</ul>
<div class="custom_button_large">
          <ul>
            <li class="red_btn"> <a href="#">Buy Now </a></li>
           
          </ul>
        </div>

</div>
<div class="package">
<ul>
<li class="p_title">Digital Home Advanced</li>
<li class="price">$29.99 <span>Per Month</span></li>

<li class="features">Costs just $29.99 per month plus 
a one-time setup fee of $60</li>

<li class="features">Costs just $29.99 per month plus 
a one-time setup fee of $60</li>

</ul>
<div class="custom_button_large">
          <ul>
            <li class="red_btn"> <a href="#">Buy Now </a></li>
           
          </ul>
        </div>

</div>
<div class="package">
<ul>
<li class="p_title">Digital Home Advanced</li>
<li class="price">$29.99 <span>Per Month</span></li>

<li class="features">Costs just $29.99 per month plus 
a one-time setup fee of $60</li>

<li class="features">Costs just $29.99 per month plus 
a one-time setup fee of $60</li>

</ul>
<div class="custom_button_large">
          <ul>
            <li class="red_btn"> <a href="#">Buy Now </a></li>
           
          </ul>
        </div>

</div>

<div class="clearfix"></div>
<div class="sep2"></div>

<div class="section">
<div class="title"><h2 class="white shadow text-center">Our Client`s Feedback </h2> <span><h4 class="white text-center">We value our client`s and appricate their intrest and feedback</h4></span></div>
<div id="owl-demo" class="owl-carousel">
        <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
          <ul>
            <li class="client_comments">Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis </li>
            <li class="desc1"> Martha M. Masters </li>
            <li class="desc2">Marketing WikiTravel </li>
          </ul>
        </div>
        <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
          <ul>
            <li class="client_comments">Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis </li>
            <li class="desc1"> Martha M. Masters </li>
            <li class="desc2">Marketing WikiTravel </li>
          </ul>
        </div>
        <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
          <ul>
            <li class="client_comments">Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis </li>
            <li class="desc1"> Martha M. Masters </li>
            <li class="desc2">Marketing WikiTravel </li>
          </ul>
        </div>
        <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
          <ul>
            <li class="client_comments">Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis </li>
            <li class="desc1"> Martha M. Masters </li>
            <li class="desc2">Marketing WikiTravel </li>
          </ul>
        </div>
      </div>

</div>

<div class="rights"><p class="white text-center">All Rights resrverd bhooce.com, 2014</p></div>
</div>
</div>
<div class="section_bottom">
<div class="container">
	
    <div class="section_top_inner">
		<div class="top_left col-lg-7 col-sm-8">
			<div class="items">
			<ul>
			<li><img src="include/images/phone.png"></li>
			<li>Customer Care - <span>1 800 237 3901</span></li>


			</ul>
			</div>
	
            <div class="items">
            <ul>
            <li><img src="include/images/chat.png"></li>
            <li><a href=""><span>Live Chat</span>
            with technical expert</a></li>
            
            
            </ul>
            </div>

		</div>
<div class="top_right col-lg-5 col-sm-4">

<div class="social">
      <ul>
        <li><a href=""><img src="include/images/fb.png" /></a></li>
        <li><a href=""><img src="include/images/twitter.png" /></a></li>
        <li><a href=""><img src="include/images/linkedin.png" /></a></li>
        <li><a href=""><img src="include/images/youtube.png" /></a></li>
     
      </ul>
    </div>

</div>

</div>
</div>
</div>

</div>
<script>
$(document).ready(function() {
        $('#show').click(function() {
                $('#entsol').slideToggle("slow");
				
    			$("#show span").toggleClass('glyphicon-plus glyphicon-minus');


        });
    });

</script>

<script>
    $(document).ready(function(){
       $('#show').mouseover(function(){
           $(this).tooltip('show');
       }) ;
    });
</script>
</body>
</html>