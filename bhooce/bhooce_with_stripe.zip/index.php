<?php include('template/header.php');

    global $geoplugin;
    global $phoneNumber;
    $price = "";
    $priceMonthly = $geoplugin->convert(19.99, 2, true);




?>

    <div class="clearfix"></div>
    <!--Slider -->

    <div class="slider">

    <div id="main-slider" class="carousel slide carousel-fade" data-ride="carousel" >
      <ol class="carousel-indicators">
        <li data-target="#main-slider" data-slide-to="0" class="active"></li>
        <li data-target="#main-slider" data-slide-to="1"></li>
        <li data-target="#main-slider" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
        <div class="item active"> <img src="include/images/bg.jpg" alt="First slide">
          <div class="carousel-caption">
            <ul>
            <li class="heading">Diagnosis & Repair </li>
            <li><img src="include/images/repair_white.png"></li>
            <li class="desc">Don't throw away that <a href="#devices" style="color: #9d72ca; cursor: pointer;" class="device-list wobble-horizontal" title="Click to see supported devices">device</a>! We can definitely help resolve the issue. Give us a call or contact our <a href="">Live Chat</a> for help. Remember you get a full refund if it doesn't get fixed! Don't just take our word for it, give us a try for just <span style="color: blueviolet"><?php echo $priceMonthly;?></span> a month.</li>
            </ul>
            <div class="custom_button">
              <ul>
                <li class="yellow_btn"> <a href="about_us.php">Find Out More</a></li>
                <li class="red_btn"> <a href="#pricing">Subscribe Now</a></li>
              </ul>
            </div>


          </div>
        </div>

          <div class="item"> <img src="include/images/diagnosex.jpg" alt="Third Slide">
              <div class="carousel-caption">
                  <ul>
                      <li class="heading">Doorstep Repair Services</li>
                      <li><img src="include/images/repair.png"></li>
                      <li class="desc">Book one of our engineer via <a href="">Live Chat</a> for 100% same day service. We have a No fix, no payment rules so you can be rest assured your devices will be well taken cared of. </li>
                  </ul>
                  <div class="custom_button">
                      <ul>
                          <li class="yellow_btn"><a href="about_us.php">Find Out More</a></li>
                          <li class="red_btn"><a href="#pricing">Subscribe Now</a></li>
                      </ul>
                  </div>
              </div>

          </div>


        <div class="item"> <img src="include/images/bg2.jpg" alt="First slide">
          <div class="carousel-caption">
            <ul>
            <li class="heading">Setup & Installation </li>
            <li><img src="include/images/installation_white.png"></li>
            <li class="desc">Install and configure your software just like you want it. Remove any unwanted application and associated files giving your computer more room to work efficiently. Rely on a 24/7 service you can call on when you most need it!</li>
            </ul>
            <div class="custom_button">
              <ul>
                <li class="yellow_btn"> <a href="about_us.php">Find Out More</a></li>
                <li class="red_btn"> <a href="#pricing">Subscribe Now</a></li>
              </ul>
            </div>


          </div>
        </div>

        <div class="item"> <img src="include/images/bg3.jpg" alt="First slide">
          <div class="carousel-caption">
            <ul>
            <li class="heading">Maintenance Services </li>
            <li><img src="include/images/maintenance_white.png"></li>
            <li class="desc">Troubleshoot your computer's hardware devices for any compatibility issues, update the device drivers if applicable and fix error preventing your device from being at its best. We've been doing this for years...</li>
            </ul>
            <div class="custom_button">
              <ul>
                <li class="yellow_btn"> <a href="about_us.php">Find Out More</a></li>
                <li class="red_btn"> <a href="#pricing">Subscribe Now</a></li>
              </ul>
            </div>


          </div>
        </div>

          <div class="item"> <img src="include/images/bg4.jpg" alt="Third Slide">
              <div class="carousel-caption">
                  <ul>
                      <li class="heading">Virus, Spyware & Malware Remover</li>
                      <li><img src="include/images/maintenance_white.png"></li>
                      <li class="desc">Detect and eliminate threats lurking in your computer; deploy solutions that provides a permanent fix to annoying pop-ups; protect your data and identity from loss; keep your system safe and improve system stability.</li>
                  </ul>
                  <div class="custom_button">
                      <ul>
                          <li class="yellow_btn"><a href="about_us.php">Find Out More</a></li>
                          <li class="red_btn"><a href="#pricing">Subscribe Now</a></li>
                      </ul>
                  </div>
              </div>

          </div>

          <div class="item"> <img src="include/images/big_screen.jpg" alt="Third Slide">
              <div class="carousel-caption">
                  <ul>
                      <li class="heading">Virus, Spyware & Malware Remover</li>
                      <li><img src="include/images/maintenance_white.png"></li>
                      <li class="desc">Detect and eliminate threats lurking in your computer; deploy solutions that provides a permanent fix to annoying pop-ups; protect your data and identity from loss; keep your system safe and improve system stability.</li>
                  </ul>
                  <div class="custom_button">
                      <ul>
                          <li class="yellow_btn"><a href="about_us.php">Find Out More</a></li>
                          <li class="red_btn"><a href="#pricing">Subscribe Now</a></li>
                      </ul>
                  </div>
              </div>

          </div>

      </div>
      <a class="left carousel-control" href="#main-slider" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span> </a> <a class="right carousel-control" href="#main-slider" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span> </a> </div>

    </div>

    <!--after slider -->
    <div class="section">
    <div class="container">
    <div class="title"><h2 class="text-center">Call <span class="red"><?php echo($phoneNumber);?></span></h2>
    <h4 class="text-center">for Instant Tech Support NOW!</h4></div>
    </div>
        <!-- <h4 class="choose" style="text-align: center">
              <ul class="texts">
                  <!-- <li>Or</li>
                   <li>Select a solution below</li>
               </ul>
        </h4>-->

    </div>


    <!-- Modal -->

    <div class="solutions">
    <ul>
    <li id="show" data-toggle="tooltip" data-placement="top" title="Select your specific solution"><span class="glyphicon glyphicon-plus"></span></li>

    </ul>
    </div>

    <div class="section" id="entsol">
    <div class="container">

         <div class="services">
            <div class="services_item">
                 <a href="">
        <ul>
            <li><img src="include/images/home.png"></li>
            <li><h3>Home Solutions </h3></li>


        </ul>
    </a>
    </div>

    <div class="services_item">
    <a href="">
    <ul>
    <li><img src="include/images/business.png"></li>
    <li><h3>Business Solutions </h3></li>

    </ul>
    </a>
    </div>
    <div class="services_item">
    <a href="">
    <ul>
    <li><img src="include/images/enterprize.png"></li>
    <li><h3>Enterprise Solutions</h3></li>

    </ul>
    </a>
    </div>


    </div>
    </div>
    </div>

    <div class="section">
        <div class="sep1"></div>

        <div class="container animation-container">
    <div class="services" id="object">
    <div class="services_item" >
    <a href="diagnosis.php">
    <ul>
    <li><img src="include/images/repair.png"></li>
    <li><h3>Diagnosis & Repair </h3></li>
    <li><p>The one stop comprehensive diagnostic & repair station for your computer and connected devices. we can fix anything ! - </p></li>
    <li><span class="glyphicon glyphicon-chevron-down red"></span></li>
    </ul>
    </a>
    </div>

    <div class="services_item">
    <a href="">
    <ul>
    <li><img src="include/images/installation.png"></li>
    <li><h3>Setup & Installation </h3></li>
    <li><p>The one stop comprehensive diagnostic & repair station for your computer and connected devices. we can fix anything ! - </p></li>

    <li><span class="glyphicon glyphicon-chevron-down red"></span></li>
    </ul>
    </a>
    </div>
    <div class="services_item">
    <a href="">
    <ul>
    <li><img src="include/images/maintenance.png"></li>
    <li><h3>Maintenance Services </h3></li>
    <li><p>The one stop comprehensive diagnostic & repair station for your computer and connected devices. we can fix anything ! - </p></li>

    <li><span class="glyphicon glyphicon-chevron-down red"></span></li>
    </ul>
    </a>
    </div>


    </div>

    </div>

 </div>


    <div class="services2">

    <div class="container animation-container" id="object2">

    <div class="title"><h2 class="white text-center">How We Deliver </h2> <span><h4 class="white text-center">Sed ut perspiciatis unde omnis iste natus<br> error sit voluptatem accusantium
    doloremque laudantium, totam </h4></span></div>


    <div class="services2-content" id="object2">
    <div class="services2-item">
    <a href="">
    <ul>
    <li><img src="include/images/tech.png" id="scale"></li>
    <li class="heading white">Tech Support</li>
    <li class="desc white">We make technology easier
    for you with instant support. </li>
    <li><span class="glyphicon glyphicon-chevron-down red"></span></li>

    </ul>
    </a>
    </div>
    <div class="services2-item">
    <a href="">
    <ul>
    <li><img src="include/images/downloads.png" id="scale"></li>
    <li class="heading white">Downloads</li>
    <li class="desc white">We make technology easier
    for you with instant support. </li>
    <li><span class="glyphicon glyphicon-chevron-down red"></span></li>

    </ul>
    </a>
    </div>
    <div class="services2-item">
    <a href="">
    <ul>
    <li><img src="include/images/videos.png" id="scale"></li>
    <li class="heading white">Videos</li>
    <li class="desc white">We make technology easier
    for you with instant support. </li>
    <li><span class="glyphicon glyphicon-chevron-down red"></span></li>

    </ul>
    </a>
    </div>
    <div class="services2-item">
    <a href="">
    <ul>
    <li><img src="include/images/social.png" id="scale"></li>
    <li class="heading white">Social</li>
    <li class="desc white">We make technology easier
    for you with instant support. </li>
    <li><span class="glyphicon glyphicon-chevron-down red"></span></li>

    </ul>
    </a>
    </div>



    <div class="clearfix"></div>
    <div class="sep1"></div>

    <div class="p2 white text-center">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque <br>corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</div>

    </div>
    </div>

    </div>



    <div class="support">
    <div class="container animation-container" id="devices">
    <div class="star text-center"><img src="include/images/star.png"></div>
    <div class="title"><h2 class="white text-center">What Devices Do We Support?</h2> <span><h4 class="white text-center">We provide computer repair services for almost everything !</h4></span></div>




    <div class="devices" >


    <ul>
    <li><img src="include/images/pc.png"><span>Desktop PCs</span></li>
    <li><img src="include/images/laptop.png"><span>Laptops</span></li>
    <li><img src="include/images/sphone.png"><span>Smart Phones</span></li>
    <li><img src="include/images/tablet.png"><span>Tablets</span></li>
    <li><img src="include/images/printer.png"><span>Printers</span></li>
    <li><img src="include/images/router.png"><span>Routers</span></li>
    </ul>

    </div>

    <div class="clearfix"></div>
    <div class="sep1"></div>

    <div class="p2 white text-center">Have a pressing need or just need to talk to someone about an issue, speak to one of our specialist via our <a href="#">Live Chat</a>  </div>

    <div class="title"><h2 class="white text-center">Call <span class="red"><?php echo ($phoneNumber);?></span></h2>
    <h4 class="text-center white">for Instant Tech Support NOW!</h4></div>

    </div>



    </div>

    <div class="special_offer">
    <div class="container">

    <div class="sec_left col-lg-9">
    <div class="title special"><h3 class="white" >2 weeks on us!</h3></div>
    <div class="p2 white special">Don't just take our word for it, take advantage of this two weeks trial and see why we've had so much fun doing these..</div>
    </div>
    <div class="custom_button mrg" id="lets">
              <ul>
                <li class="yellow_btn"> <a href="#pricing">OK Let's go!</a></li>

              </ul>
            </div>
    </div>
    </div>
<div class="counter">

    <div class="container">
      <ul>
          <li class="icon"><span class="glyphicon glyphicon-user"></span></li>
          <li><h1 class="jumbo" id="myTargetElement">15.02</h1></li>
          <li>Satisfied Customers</li>
      </ul>
        <ul>
            <li class="icon"><span class="glyphicon glyphicon-ok"></span></li>
            <li><h1 class="jumbo" id="myTargetElement2">1511.02</h1></li>
            <li>Countries Supported</li>
        </ul>
       <!-- <ul>

            <li class="icon"><span class="glyphicon glyphicon-send"></span></li>
            <li><h1 class="jumbo" id="myTargetElement3">1111.02</h1></li>
            <li>Home Users</li>
        </ul>

        <ul>

            <li class="icon"><span class="glyphicon glyphicon-pencil"></span></li>
            <li><h1 class="jumbo" id="myTargetElement4">345.02</h1></li>
            <li>Business Users</li>
        </ul>-->

    </div>

</div>
    <?php include('template/pricing.php');?>
    <?php include('template/footer.php');?>

    </div>

    </body>
    </html>

<script type="text/javascript">

</script>