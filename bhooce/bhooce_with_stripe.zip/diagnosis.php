<?php include('template/header.php');?>


<div class="clearfix"></div>
<!--Slider -->

<div class="big_image2">

    <div class="container">

        <div class="big_image_title text-center"><h1>We Can Repair Anything and we mean it !</h1> <span>omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet </span></div>

        <div class="custom_button text-center">
            <ul>

                <li class="red_btn"> <a href="#">Subscribe Now</a></li>
            </ul>
        </div>

    </div>


</div>

<div class="section">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="index.php">Home</a> </li>
            <li><a href="services.php">Services</a> </li>
            <li class="active"><a href="services.php">Diagnosis & Repair</a> </li>

        </ul>

    </div>

</div>




<div class="section">
    <div class="container animation-container">

        <div class="title"><h2 class="text-center">Diagnosis & Repair</h2> <span><h5 class="text-center gray">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
            doloremque laudantium, totam </h5></span></div>

        <div class="ser_expalined">

            <div class="ser col-lg-5">
                <div class="place_holder" id="snapshot2"><img src="include/images/mockup.png" class="img-responsive"></div>

            </div>
            <div class="ser col-lg-7">
                <ul>
                    <li><span>Fix Software and Hardware Errors</span>
                        iYogi tech experts will diagnose and troubleshoot both software and hardware errors on your PCs or servers to ensure smooth performance.
                    </li>

                    <li><span>Fix Software and Hardware Errors</span>
                        iYogi tech experts will diagnose and troubleshoot both software and hardware errors on your PCs or servers to ensure smooth performance.
                    </li>

                    <li><span>Fix Software and Hardware Errors</span>
                        iYogi tech experts will diagnose and troubleshoot both software and hardware errors on your PCs or servers to ensure smooth performance.
                    </li>

                    <li><span>Fix Software and Hardware Errors</span>
                        iYogi tech experts will diagnose and troubleshoot both software and hardware errors on your PCs or servers to ensure smooth performance.
                    </li>
                </ul>


            </div>

        </div>


        <div class="ser_expalined">


            <div class="ser col-lg-7">
                <ul>
                    <li><span>Fix Software and Hardware Errors</span>
                        iYogi tech experts will diagnose and troubleshoot both software and hardware errors on your PCs or servers to ensure smooth performance.
                    </li>

                    <li><span>Fix Software and Hardware Errors</span>
                        iYogi tech experts will diagnose and troubleshoot both software and hardware errors on your PCs or servers to ensure smooth performance.
                    </li>

                    <li><span>Fix Software and Hardware Errors</span>
                        iYogi tech experts will diagnose and troubleshoot both software and hardware errors on your PCs or servers to ensure smooth performance.
                    </li>

                    <li><span>Fix Software and Hardware Errors</span>
                        iYogi tech experts will diagnose and troubleshoot both software and hardware errors on your PCs or servers to ensure smooth performance.
                    </li>
                </ul>


            </div>

            <div class="ser col-lg-5">
                <div class="place_holder" id="snapshot"><img src="include/images/optimization_img.png" class="img-responsive"></div>

            </div>


        </div>
    </div>

</div>




<div class="section">
    <div class="container">
        <div class="title"><h2 class="text-center">Call <span class="red">1 800 237 3901</span></h2>
            <h4 class="text-center">for Instant Tech Support NOW!</h4></div>
    </div>


</div>


<!-- Modal -->

<div class="solutions">
    <ul>
        <li id="show" data-toggle="tooltip" data-placement="top" title="Select specific solution"><span class="glyphicon glyphicon-plus"></span></li>

    </ul>
</div>

<div class="section" id="entsol">
    <div class="container">

        <div class="services">
            <div class="services_item">
                <a href="">
                    <ul>
                        <li><img src="include/images/home.png"></li>
                        <li><h3>Home Solutions </h3></li>


                    </ul>
                </a>
            </div>

            <div class="services_item">
                <a href="">
                    <ul>
                        <li><img src="include/images/business.png"></li>
                        <li><h3>Business Solutions </h3></li>

                    </ul>
                </a>
            </div>
            <div class="services_item">
                <a href="">
                    <ul>
                        <li><img src="include/images/enterprize.png"></li>
                        <li><h3>Enterprize Solutions</h3></li>

                    </ul>
                </a>
            </div>


        </div>
    </div>
</div>




<div class="special_offer">
    <div class="container">

        <div class="sec_left col-lg-9">
            <div class="title special"><h3 class="white">2 weeks on us!</h3></div>
            <div class="p2 white special">Don't just take our word for it, take advantage of this two weeks trial and see why we've had so much fun doing these..</div>
        </div>
        <div class="custom_button mrg">
            <ul>
                <li class="yellow_btn"> <a href="#">OK Lets go! </a></li>

            </ul>
        </div>
    </div>
</div>

<?php include('template/pricing.php');?>

<?php include('template/footer.php');?>

</div>
<script type="text/javascript">
    $(document).ready(function() {
        $('#show').click(function() {
            $('#entsol').slideToggle("slow");

            $("#show span").toggleClass('glyphicon-plus glyphicon-minus');


        });
    });

</script>

<script type="text/javascript">
    $(document).ready(function(){
        $('#show').mouseover(function(){
            $(this).tooltip('show');
        });
    });
</script>
</body>
</html>