<?php
/**
 * Created by PhpStorm.
 * User: Kunle
 * Date: 01/04/14
 * Time: 13:19
 */

require('dbclass.php');

$timezone = "";

$language = $_COOKIE['language'];
if (($language) == 'US'){
    $timezone = 'America/Newyork';
} else {
    $timezone = 'Europe/London';
}

define("MAX_SIZE", "1000");
date_default_timezone_get($timezone);

function SELECT ($SELECT, $WHERE, $TABLE, $CALLBACK) {
    global $obj;
    $RETURN = "";
    $query = "SELECT ".$SELECT." FROM `".$TABLE."` WHERE ".$WHERE."";
    //echo $query;
    $value = $obj->query_db($query);
    $res = $obj->fetch_db_assoc($value);

    switch ($CALLBACK) {
        case 'array':
            if ($res > 0) {
                $RETURN = $res;
            } else {
                $RETURN = false;
            }
            break;

        case 'bool' :
            if ($res > 0) {
                $RETURN = true;
            } else {
                $RETURN = false;
            }
            break;

        case 'numrows' :
            $RETURN = $obj -> num_rows($value);
            break;

        default:
            $RETURN = "ERROR!".mysql_error();
    }

    return $RETURN;
}

function INSERT($value ,$table ,$callback ,$extra) {
    global $obj;
    $RETURN = "";
    $column = $obj -> show_column_names(''.$table.'');
    $query = "INSERT INTO `".$table."` (" . $column . ") VALUES ( " . $value . ")";
    //echo $query;
    switch($callback) {
        case false:

            $value = $obj->query_db($query);
            if($value) {
                $RETURN = true;
            } else {
                $RETURN = "ERROR!".mysql_error();
            }
            break;
        case 'unique':
            if(!SELECT('*', $extra, $table, 'bool')) {
                $value = $obj->query_db($query);
                if($value) {
                    $RETURN = true;
                } else {
                    $RETURN = "ERROR!".mysql_error();
                }
            } else {
                $RETURN = false;
            }
            break;
        case 'id':
            $value = $obj->query_db($query);
            if($value) {
                $RETURN = true;
            } else {
                $RETURN = "ERROR!".mysql_error();
            }
            $RETURN = $obj -> id_db();
            break;
        default:
            $RETURN = "ERROR!".mysql_error();
    }

    return $RETURN;
}

function getRealIpAddr() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {   //check ip from share internet
        $ip=$_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  //to check ip is pass from proxy
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    } else{
        $ip=$_SERVER['REMOTE_ADDR'];
    }

    return $ip;
}

function singleFileUpload ($FILES , $name) {
    $imageName = '';
    $errors=0;
    $msg = "";
    $image=$FILES[$name]['name'];
    if ($image) {
        $filename = stripslashes($FILES[$name]['name']);
        $extension = getExtension($filename);
        $extension = strtolower($extension);
        if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {
            $msg = 'Unknown Image Extension!';
            $errors=1;
        } else {
            $size=filesize($FILES[$name]['tmp_name']);

            if ($size > MAX_SIZE*1024){
                $msg = 'You have exceeded the size limit!';
                $errors=1;
            } else {
                $image_name= 'item_'.time().'.'.$extension;
                $newname="../items-pictures/".$image_name;
                $copied = copy($FILES[$name]['tmp_name'], $newname);
                if (!$copied){
                    $errors=1;
                    $msg = 'Image Not Upload!!';
                } else {
                    $imageName = $image_name;
                }
            }
        }
    }
    $RETURN = array('error' => $errors , 'img_name' => $imageName , 'msg' => $msg);
    return $RETURN;
}

function getExtension($str) {
    $i = strrpos($str,".");
    if (!$i) { return ""; }
    $l = strlen($str) - $i;
    $ext = substr($str,$i+1,$l);
    return $ext;
}


function calcMinDis($array) {
    asort($array);

    $_SESSION['TO_STAFF_ORDER_ARRAY'] = $array;

    foreach($array as $key => $value) {
        $return[$key] = $value;
        break;
    }
    return $return;
}

function getEandN($postcode) {
    $postcode = str_replace(' ' ,'%20' ,$postcode);
    $array = csv_to_array('http://www.doogal.co.uk/UKPostcodesCSV.php?Search='.$postcode.'');
    if(count($array)){
        foreach($array as $value) {
            $ar['E'] = $value['Easting'];
            $ar['N'] = $value['Northing'];
            break;
        }
    } else {
        $ar = false;
    }
    return $ar;
}

function toStaffId($EandN ,$postcode){
    global $obj;

    $query = $obj -> query_db("SELECT * FROM `staff` WHERE `staff_status` = 'active'");
    while($result = $obj -> fetch_db_array($query)){
        $fetchres = json_decode($result['staff_postcode'] , true);
        $GUYPOST[$result['staff_id']] = $fetchres;
        $fetchres_postcode[] = str_replace(' ', '',key($fetchres));
    }

    $fetch_postcode = implode('|', $fetchres_postcode);
    $google_result = getMatrix(str_replace(' ', '',$postcode), $fetch_postcode);

    $isResultFromGoogle = true;
    if($google_result['error'] == 'false'){
        $i = 0;
        foreach($GUYPOST as $k => $v){
            $array[$k] = $google_result['output'][$fetchres_postcode[$i]];
            $i ++;
        }
    } else {
        foreach($GUYPOST as $k => $v){
            foreach($v as $key => $value){
                $array[$k] = calcDistance($value['N'] ,$EandN['N'] ,$value['E'] ,$EandN['E']);
            }
        }
    }
    asort($array);
    //$narray = calcMinDis($array);

    $RETURN_ID = 'false';
    $nowTime = strtotime(date('H:i'));

    foreach($array as $id => $distence) {
        $detail = getOneStaffDetail($id ,array('staff_max_distence', 'staff_available_time'));
        $detail_time = json_decode(stripslashes($detail['staff_available_time']), true);

        if(($distence <= $detail['staff_max_distence']) && ($nowTime >= strtotime($detail_time[date('l')]['From']) && $nowTime <= strtotime($detail_time[date('l')]['To']))){
            $RETURN_ID = $id;
            break;
        }
    }
    return $RETURN_ID;
}

function getOneStaffDetail($id, $col) {
    global $obj;

    $columns = "";

    foreach($col as $val) {
        $columns .= "`".$val."` ,";
    }

    $columns = substr($columns , 0, -1);
    $query = $obj -> query_db("SELECT ".$columns." FROM `staff` WHERE `staff_id` = '".$id."' AND `staff_status` = 'active'");
    $result = $obj -> fetch_db_assoc($query);
    return $result;
}

function getMilesFromRest($postcode) {
    global $obj;

    $query = $obj -> query_db("SELECT * FROM `location` WHERE `location_status` = 'active'");
    while($result = $obj -> fetch_db_assoc($query)){
        $GUYPOST[] = json_decode($result['location_postcode'] , true);
    }

    foreach($GUYPOST as $k => $v){
        foreach($v as $key => $value){
            $array[$k] = calcDistance($value['N'] ,$postcode['N'] ,$value['E'] ,$postcode['E']);
        }
    }

    $narray = calcMinDis($array);



    foreach($narray as $mind){
        $RETURN = $mind;
        break;
    }
    return $mind;
}


function admin_email(){
    global $obj;

    $query5 = $obj -> query_db("SELECT `admin_email` FROM `setting`");
    $res5 = $obj->fetch_db_assoc($query5);

    return $res5['admin_email'];
}


function getDataFromTable($table, $col){
    global $obj;

    $query5 = $obj -> query_db("SELECT `".$col."` FROM `".$table."`");
    $res5 = $obj->fetch_db_assoc($query5);

    return $res5[$col];
}

function getPId($email){
    global $obj;

    $query5 = $obj -> query_db("SELECT `j_type_id` FROM `join_restaurant` WHERE `j_email` = '".$email."'");
    $res5 = $obj->fetch_db_array($query5);

    return $res5['j_type_id'];
}

function checkPId($PID , $email){
    global $obj;

    $query5 = $obj -> query_db("SELECT `j_type_id` FROM `join_restaurant` WHERE `j_type_id` = '".$PID."' AND `j_email` = '".$email."' AND `j_status` = 'active'");
    if($obj -> num_rows($query5) > 0){
        return true;
    } else {
        return false;
    }
    return false;
}

function setC($name,$text) {
    $expire=time()+907200;
    setcookie($name, $text, $expire);
}

function showC($name){
    //if($status) {
    (isset($_COOKIE[$name])) ? $RETURN =  $_COOKIE[$name] :	$RETURN = false;
    return $RETURN;
    //}
}

function checkC(){
    //if($_SESSION)
}




