<?php
	define('STRIPE_LIVE_PK', 'pk_live_ilF5EvWx76sIw49zdNB8KNsG');
	define('STRIPE_LIVE_SK', 'sk_live_30hkNXblsQSIk5kb99hKCJGW');

	define('STRIPE_TEST_PK', 'pk_test_ecX0Mmax9r3pLTmgHj6uu5xq');
	define('STRIPE_TEST_SK', 'sk_test_BSDZdsgxo2q7upjMKWHTq73r');
?>