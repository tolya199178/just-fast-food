<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kunle
 * Date: 23/03/14
 * Time: 23:54
 * To change this template use File | Settings | File Templates.
 */
include('template/header.php');?>

<div class="clearfix"></div>

 <div class="big_image3">
     <div class="container">
         <div class="big_image_title text-center">
         </div>
         <div class="custom_button text-center">
             <ul>
                 <!--<li class="red_btn"> <a href="#">Subscribe Now</a></li>-->
             </ul>
         </div>
     </div>
 </div>




    <div class="section" >
        <div class="container animation-container">
            <div class="title"><h2 class="text-left" style="color: #575790">Overview</h2> <span><h5 class="text-left gray"> </h5></span></div>
             <h5 class="content"><span style="color: #4e7d8f; font-weight: bolder">Bhooce</span>&reg; is one of the leading provider of both Remote and On-site technical support services committed to providing tech support services to both home and small businesses. We provide guaranteed satisfaction for your tech services to solve all your PC issues, giving your system a 'like-new' performance or your money back.  </h5>
            <h5 class="content">Get <span style="color: #4e7d8f" class="push">IMMEDIATE</span> live help with your computers, network and gadgets. It is designed to eliminate computer-related stress and keep millions of digitally dependent computer users and small businesses always protected and productive. </h5>
            <h5 class="content">Our technical specialist are always on 24/7 via <a href="#">Live Chat</a>. We ensure all staffs are well trained to provide the best service at any given time. </h5>
            <h5 class="content">Our online and on premise tech support are conducted by highly qualified personal technology experts who are based in our help center. All of <span style="color: #4e7d8f; font-weight: bolder">Bhooce</span>&reg; staff members have to be professionally trained and certified before assisting customers. </h5>
            <h5 class="content">
                Our technical support specialists have sufficient expertise in dealing with all types of viruses and malware, registry issues and Windows 'Blue Screen' issues to mention but a few.Full details of supported devices and solution provided can be found <a href="#">here</a>.</h5>
            <div class="content"></div>
            <hr class="sep1">
            <div class="title"><h3 class="text-left" style="color: #575790">Why are we different?</h3> <span><h5 class="text-left gray"> </h5></span></div>

            <h6 class="content"style="width: 60%">Among many reasons on why we are different are highlighted below, don't just take our word for it though, give us a try :</h6>
             <ul class="list-unstyled ">
                <li><i class="icon-ok color-sea"></i> Certified technicians with over 7 years experience use trusted lab-tested tools for repair and diagnosis. </li><br/>
                <li><i class="icon-ok color-sea"></i> Fast, affordable and more convenient than in-store repair or phone.</li><br/>

                <li><i class="icon-ok color-sea"></i> Over 97% of our customers from over the world are satisfied and rate <span style="color: #4e7d8f; font-weight: bolder">Bhooce</span>&reg; as leading provider.</li><br/>

                <li><i class="icon-ok color-sea"></i> No risk & cost-effective: all service purchases are covered by our money-back guarantee.</li><br/>
                <li><i class="icon-ok color-sea"></i> Fast, effective and affordable service with 100% satisfaction guarantee.</li><br/>

            </ul>
            <img src="include/images/tech-job2.jpg" style="float: right; width: 35%; margin-top: -18em; border-radius: 10px"><br/>
            <hr class="sep1">

            <div class="row">
                <div class="col-md-5">
                    <div id="testimonials-1" class="carousel slide testimonials testimonials-v1" id="testimonials-1"">
                        <div class="carousel-inner">
                            <div class="item active">
                                <p>We couldn't be happier.. Bhooce technicians was on time, resolution within 45 minutes for a 2 hours service. Services rendered saved us so much and still in use. </p>
                                <div class="testimonial-info">
                                    <img alt="" src="include/images/client.jpg">
                            <span class="testimonial-author">
                               Morire Adetayo
                                <!--<em>Web Developer, Unify Theme.</em>-->
                            </span>
                                </div>
                            </div>
                            <div class="item">
                                <p>These guys knows what they are doing. If you're looking for the best bet for your money and a reliable service, please look no further than this guys!</p>
                                <div class="testimonial-info">
                                    <img alt="" src="include/images/client.jpg">
                            <span class="testimonial-author">
                                Moji Adetayo
                                <!--<em>Java Developer, Htmlstream</em>-->
                            </span>
                                </div>
                            </div>
                        </div>
                    <div class="carousel-arrow">
                        <a class="left carousel-control" href="#testimonials-1" data-slide="prev">
                            <i class="icon-angle-left"></i>
                        </a>
                        <a class="right carousel-control" href="#testimonials-1" data-slide="next">
                            <i class="icon-angle-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="custom_button" style="text-align: end; margin-top: -10em">
            <div class="red_btn">
                <ul>
                    <li class="red_btn"> <a href="#">Subscribe Now</a></li>
                </ul>
            </div>
        </div>
        </div>
</div>






    <?php include('template/footer.php');?>