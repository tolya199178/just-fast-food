<?php
/**
 * Created by PhpStorm.
 * User: Kunle
 * Date: 24/03/14
 * Time: 23:18
 */
?>

<!DOCTYPE html>

<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7; IE=EmulateIE9">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Bhooce: Online Techinal Support</title>

    <!--CSS INCLUDES-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,700italic,800italic,400,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,700italic,900' rel='stylesheet' type='text/css'>
    <link href="css/awwal.css" rel="stylesheet">
    <link href="css/menu.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/media.css" rel="stylesheet">


    <!--FONTS INCLUDE-->

    <!--
    JS INLCUDES-->
    <script src="js/jquery-1.7.2.min.js"></script>
    <script src="js/superfish.js"></script>
    <script src="js/responsive-nav.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>


</head>
<body>
<div class="wrapper">
    <header>
        <div class="section_top">
            <div class="container">

                <div class="section_top_inner">
                    <div class="top_left col-lg-6 col-sm-6">
                        <div class="items">
                            <ul>
                                <li><img src="images/phone.png"></li>
                                <li>Customer Care - <span>1 800 237 3901</span></li>


                            </ul>
                        </div>

                        <div class="items">
                            <ul>
                                <li><img src="images/chat.png"></li>
                                <li><a href=""><span>Live Chat</span>
                                        with technical expert</a></li>


                            </ul>
                        </div>



                    </div>
                    <div class="top_right col-lg-6 col-sm-6">
                        <div class="social">
                            <ul>
                                <li><a href=""><img src="images/fb.png" /></a></li>
                                <li><a href=""><img src="images/twitter.png" /></a></li>
                                <li><a href=""><img src="images/linkedin.png" /></a></li>
                                <li><a href=""><img src="images/youtube.png" /></a></li>

                            </ul>
                        </div>
                        <div class="login">
                            <ul>
                                <li><img src="images/account.png"><a href="">Sign In</a></li>
                                <li><img src="images/register.png"><a href="">Register</a></li>


                            </ul>
                        </div>



                    </div>

                </div>
            </div>
        </div>
        <div class="clearfix"></div>

        <div class="container">
            <div class="section_nav">
                <div class="logo col-lg-3 col-sm-4" ><img src="images/logo.png" alt="Bhooce"></div>

                <nav id="main_menu" class="col-lg-6 col-sm-8">
                    <div class="menu_wrap">
                        <ul class="nav sf-menu">
                            <li class="active"><a href="index.php">Home</a></li>

                            <li class="sub-menu"><a href="javascript:{}">About</a></li>

                            <li class="sub-menu"><a href="services.php">Services</a>
                                <ul>
                                    <li><a href="diagnosis.php">Home Services </a>
                                        <ul style="font-family: "GE Inspira"">
                                    <li><a href="#">Virus & Malware Removal</a> </li>
                                    <li><a href="#">Data recovery and backup solutions</a> </li>
                                    <li><a href="#">Startup optimisation</a> </li>
                                    <li><a href="#">Wifi configuration</a> </li>
                                </ul>
                            </li>
                            <li><a href="#">Business Solutions</a>
                                <ul>
                                    <li><a href="#">Network infrastructure (routers/firewalls)</a> </li>
                                    <li><a href="#">Software installation, rollouts, and upgrades</a> </li>
                                    <li><a href="#">Servers</a> </li>
                                    <li><a href="#">VoIP installation and configuration</a> </li>
                                    <li><a href="#">Onsite & Remote support</a> </li>

                                </ul>
                            </li>
                            <li><a href="#">Enterprise Solutions</a>
                                <ul>
                                    <li><a href="#">VPN design, installation and Support</a> </li>
                                    <li><a href="#">Printer maintenance</a> </li>
                                    <li><a href="#">Hardware repair</a> </li>
                                    <li><a href="#">Wireless network repair</a> </li>
                                </ul>
                            </li>

                           </ul>


                            <li class="sub-menu"><a href="javascript:{}">Support</a></li>



                            <li class="sub-menu"><a href="javascript:{}">Contact</a>

                            </li>
                        </ul>
                    </div>
                </nav>

            </div>
        </div>
    </header>