<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kunle
 * Date: 23/03/14
 * Time: 15:25
 * To change this template use File | Settings | File Templates.
 */
?>

<div class="section_bottom">
    <div class="container">

        <div class="section_top_inner">
            <div class="top_left col-lg-7 col-sm-8">
                <div class="items">
                    <ul>
                        <li><img src="include/images/phone.png"></li>
                        <li>Customer Care - <span>1 800 237 3901</span></li>


                    </ul>
                </div>

                <div class="items">
                    <ul>
                        <li><img src="include/images/chat.png"></li>
                        <li><a href=""><span>Live Chat</span>
                                with technical expert</a></li>


                    </ul>
                </div>

            </div>
            <div class="top_right col-lg-5 col-sm-4">

                <div class="social">
                    <ul>
                        <li><a href=""><img src="include/images/fb.png" /></a></li>
                        <li><a href=""><img src="include/images/twitter.png" /></a></li>
                        <li><a href=""><img src="include/images/linkedin.png" /></a></li>
                        <li><a href=""><img src="include/images/youtube.png" /></a></li>

                    </ul>
                </div>

            </div>

        </div>
    </div>
</div>