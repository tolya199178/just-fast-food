<?php

global $geoplugin;

// pricing
global $priceHourly;
global $priceMonthly;
global $priceOneOff;

 $priceMonthly = $geoplugin->convert(19.99, 2, true);
 $priceHourly = $geoplugin->convert(80.00, 2, true);
 $priceOneOff = $geoplugin->convert(49.00, 2, true);
 //$priceHourly = $priceHourly.'0';
 //$priceOneOff = $priceOneOff.'0';


?>

<div class="section_packages">
    <div class="container animation-container" id="pricing">
        <div class="title"><h2 class="white shadow text-center" style="font-family: 'Roboto', sans-serif">Just select the service that fits your needs<br>
            and leave the rest to us. </h2></div>


        <div class="package">
            <ul>
                <li class="p_title">Remote Tech Support</li>
                <li class="price"><?php echo $priceMonthly;?> <span>Per Month</span></li>
                <li class="features"><img src="include/images/tick.png"> No setup fees</li>
                <li class="features"><img src="include/images/tick.png"> Virus, Spyware, Adware/Malware Removal</li>
                <li class="features"><img src="include/images/tick.png"> System Tune-up/Repair/Green PC</li>
                <li class="features"><img src="include/images/tick.png"> Printer/Network Setup & Maintenance</li>
                <li class="features"><img src="include/images/tick.png"> Program Install/Uninstall</li>
                <li class="features"><img src="include/images/tick.png"> Device Driver Update/Repair</li>
                <li class="features"><img src="include/images/tick.png"> Wireless Connectivity Setup & Repair</li>
                <!--<li class="features"><img src="include/images/tick.png"> MS Office/ Email Setup</li>-->
                <!-- <li class="features"><img src="include/images/tick.png"> Data Backup/Recovery</li>-->
                <li class="features"><img src="include/images/tick.png"> Unlimited Live Support</li>
                <li class="features"><img src="include/images/tick.png"> One PC, Smartphone & Printer Supported</li>



            </ul>
            <div class="custom_button_large" >
                <ul>
                    <li class="red_btn" id="basic"> <a href="subscribe.php?h=1&subType=basic">Subscribe Now </a></li>

                </ul>
            </div>

        </div>
        <div class="package">
            <ul>
                <li class="p_title">On-site Tech Support</li>
                <li class="price"><?php echo $priceHourly;?> <span>Per hour</span></li>

                <li class="features" data-out-effect="fadeOut" data-out-shuffle="true"><img src="include/images/tick.png">Onsite resolution at your Office</li>

                <li class="features" data-out-effect="fadeIn"><img src="include/images/tick.png">Active Directory / LDAP Setup & Configuration</li>
                <li class="features" data-out-effect="rollIn"><img src="include/images/tick.png">VMWare/Workstation scheduled maintenance</li>

                <li class="features"><img src="include/images/tick.png">Add-On configuration for Excel for accounting purposes</li>
                <li class="features"><img src="include/images/tick.png">Advance Backup Solutions</li>

                <li class="features"><img src="include/images/tick.png">Disaster Recovery and Fail Over solutions</li>
                <li class="features"><img src="include/images/tick.png">Router and Firewall Configuration</li>

                <li class="features"><img src="include/images/tick.png">Server Maintenance Services</li>
                <li class="features"><img src="include/images/tick.png">Network printer configuration & Installation</li>



            </ul>
            <div class="custom_button_large">
                <ul>
                    <li class="red_btn"  id="premium"> <a href="subscribe.php?h=1&subType=prem">Subscribe Now</a></li>

                </ul>
            </div>

        </div>
        <div class="package">
            <ul>
                <li class="p_title">One-Off Tune Up</li>
                <li class="price"><?php echo $priceOneOff;?> <span>Per Session</span></li>
                <li class="features"><img src="include/images/tick.png">Adware/Spyware clean up</li>
                <li class="features"><img src="include/images/tick.png">Virus removal and protection verification</li>
                <li class="features"><img src="include/images/tick.png">Antivirus installation and configuration</li>
                <li class="features"><img src="include/images/tick.png">Hard drive defragmentaion</li>
                <li class="features"><img src="include/images/tick.png">Startup optimization</li>
                <li class="features"><img src="include/images/tick.png">Temporary files cleanup</li>
                <li class="features"><img src="include/images/tick.png">Computer and Application optimization </li>

            </ul>
            <div class="custom_button_large" >
                <ul>
                    <li class="red_btn" id="one-off"> <a href="subscribe.php?h=1&subType=oneoff">Subscribe Now </a></li>

                </ul>
            </div>

        </div>

        <div class="clearfix"></div>
        <div class="sep2"></div>

        <div class="section">
            <div class="title"><h2 class="white shadow text-center">Our Client`s Feedback </h2> <span><h4 class="white text-center">We value our client`s and appreciate their interest and feedback</h4></span></div>
            <div id="owl-demo" class="owl-carousel">
                <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
                    <ul>
                        <li class="client_comments">We couldn't be happier.. Bhooce technicians was on time, resolution within 45 minutes for a 2 hours service. Services rendered saved us so much and still in use.   </li>
                        <li class="desc1"> Brian </li>
                        <li class="desc2">JFF Solutions </li>
                    </ul>
                </div>
                <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
                    <ul>
                        <li class="client_comments">These guys sure knows what they are doing. If you're looking for the best bet for your money and a reliable service, please look no further than this guys!  </li>
                        <li class="desc1"> John </li>
                        <li class="desc2">Marketing WikiTravel </li>
                    </ul>
                </div>
                <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
                    <ul>
                        <li class="client_comments">We got a service worth of $600 minimum for $80. Even more, issues hasn't replicated itself since the engineer left compare to our previous engineers. Good jobs guys!  </li>
                        <li class="desc1"> Ana </li>
                        <li class="desc2">Marketing WikiTravel </li>
                    </ul>
                </div>
                <div class="item"><img src="include/images/client.jpg" alt="Owl Image">
                    <ul>
                        <li class="client_comments">We've relied on Bhooce's services for a while now and not at one time has they failed us! </li>
                        <li class="desc1">Bridget</li>
                        <li class="desc2">Wolfs </li>
                    </ul>
                </div>
            </div>

        </div>

        <div class="rights"><p class="white text-center">All Rights reserved Bhooce.com, 2014</p></div>
    </div>
</div>


