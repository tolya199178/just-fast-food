<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kunle
 * Date: 23/03/14
 * Time: 23:54
 * To change this template use File | Settings | File Templates.
 */
include('template/header.php');?>

<div class="clearfix"></div>

<div class="support-img">
    <div class="container">
        <div class="big_image_title text-center">
        </div>
        <div class="custom_button text-center">
            <ul>
                <!--<li class="red_btn"> <a href="#">Subscribe Now</a></li>-->
            </ul>
        </div>
    </div>
</div>

<div class="section breadcrum">
    <div class="container">
        <ul class="breadcrumb">
           <!-- <li><a href="index.php">Home</a> </li>
            <li class="active"><a href="about_us.php">Support</a> </li>-->

        </ul>

    </div>
</div>

<div class="section">
    <div class="container animation-container"><div class="section">
            <div class="container animation-container">
                </div>
            </div>
        </div>
    </div>
<?php include('template/footer.php');?>