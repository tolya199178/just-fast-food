<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Just-FastFood.com | Email</title>
	<style type="text/css">
		a{
			color: #363636;
			text-decoration: underline;
		}
		a:hover{
			color:#D62725;
		}
		
	</style>
</head>
<body>
	<div class="wrapper" style="padding:15px; border:1px solid #ddd; margin:20px; font-family:Verdana;">
		<div>
			<h1 style="font: bolder 30px Rockwell,Tahoma,Arial,sans-serif; padding-bottom: 10px; margin:0px; padding:0px; color:#D62725;">Just-FastFood.com</h1>
			<span style="font-size:11px; font-family:Verdana; font-style:italic">Order your fast food online</span>
			<p style="font-size:11px; font-family:Verdana; padding:0px; text-align:right; margin:0px;">* This Email Receive From <a href="http://just-fastfood.com">Just-FastFood.com</a></p>
		</div>
		<hr style="height:1px; background:#ddd; margin:10px;"/>
		<div>
			<p style="font-size:13px; font-family:Verdana; margin:5px; padding:10px;"><?php echo $_GET['msg']?></p>
		</div>
		<hr style="height:1px; background:#ddd; margin:10px;"/>
		<div>
			<p style="font-size:12px; font-family:arial; padding-bottom:10px; color:#bbb">&copy; Just-FastFood.com</p>
			<p style="font-size:12px; font-family:arial; padding:0px; margin:0px; color:#bbb; text-align:right;font-style:italic">Powered By : M Awais</p>
		</div>
	</div>
</body>
</html>