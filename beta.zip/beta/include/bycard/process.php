<?php
	session_start();

	if(!isset($_SESSION['CARD_PROCESSING'])) {
		header('Loation:/');
		die();
	}

	require_once ("Config.php");
	require_once ("ISOCountries.php");
	require_once ("PreProcessPaymentForm.php");
	include('../functions.php');

	/* echo '<pre>';
	print_r($_POST);
	echo '</pre>'; */
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Card Pocessing - Please Wait .. - Just_fastFood</title>
</head>
<body style="background:#F0EEDF">
<form name="Form" action="<?= $FormAction ?>" method="post"<?= $FormAttributes ?>>
<?php
	switch ($NextFormMode) {
		case "RESULTS":
			echo '<input name="FormMode" type="hidden" value="'.$NextFormMode.'" />';
			if (isset($DuplicateTransaction) != true) {
				$DuplicateTransaction=false;
			}

			if ($TransactionSuccessful == false) {

				$_SESSION['error'] = '<b style="font-size:13px">ERROR in Card Details. Please Try Again <br/>'.$Message.'</b>';
				header('Location:../../pay.php');
				die();

			} else {
				require_once('../order-movement.php');

				$_SESSION['CHECKOUT_WITH'] = "By Card";
				$_SESSION['CART_SUBTOTAL'] = $_SESSION['T_CART_SUBTOTAL'];
				$_SESSION['ORDER_TRANSACTION_DETAILS'] = array($Message);
				$_SESSION['ORDER_TRANSACTION_DETAILS']['TRANSACTIONID'] = $_SESSION['Current_Trans_Id'];
				$_SESSION['user_address'] = $_SESSION['CARD_PROCESSING']['address'];
				$_SESSION['order_note'] = $_SESSION['CARD_PROCESSING']['order_note'];
				$_SESSION['user_phoneno'] = $_SESSION['CARD_PROCESSING']['user_phoneno'];
				$_SESSION['delivery_type'] = json_encode($_SESSION['delivery_type']);

				$_SESSION['CURRENT_ORDER_ID'] = insertOrder();

				$select = "`setting_auto_order`";
				$where = " 1 ";
				$result_setting = SELECT($select ,$where, 'setting', 'array');

				if(($_SESSION['RESTAURANT_TYPE_CATEGORY'] == 'fastfood') && ($result_setting['setting_auto_order'] == 'on') && ($_SESSION['delivery_type'] != 'delivery')) {
					$json_post = getEandN($_SESSION['CURRENT_POSTCODE']);
					assignOrder($_SESSION['CURRENT_ORDER_ID'] ,toStaffId($json_post ,$_SESSION['CURRENT_POSTCODE']));
				} else if($_SESSION['RESTAURANT_TYPE_CATEGORY'] == 'takeaway'){
					assignOrderTakeaway();
				}

				unset($_SESSION['CARD_PROCESSING']);
				header('location:../../order-complete.php');
				die();
			}

			print '<br><br><br><br>SUCCESS : '.$Message.'<br><br><br><br>';
			if ($DuplicateTransaction == true) {
				//echo $PreviousTransactionMessage;
				$_SESSION['error'] = '<b style="font-size:13px">Duplicate Transaction! <br/>'.$PreviousTransactionMessage.'</b>';
				header('Location:../../pay.php');
				die();
			}

		break;
		case "THREE_D_SECURE":
	?>
			<input name="PaReq" type="hidden" value="<?= $PaREQ ?>" />
			<input name="MD" type="hidden" value="<?= $CrossReference ?>" />
			<input name="TermUrl" type="hidden" value="<?= $SiteSecureBaseURL ?>ThreeDSecureLandingPage.php" />

			<iframe id="ACSFrame" name="ACSFrame" src="<?= $SiteSecureBaseURL ?>Loading.htm" width="800" height="400" frameborder="0"></iframe>
	<?php
		break;
		case "PAYMENT_FORM":

			if (isset($Message) == true) {
				if ($Message != "") {
					$_SESSION['error'] = '<b style="font-size:13px">ERROR in Card Details. Please Try Again <br/>'.$Message.'</b>';
					header('Location:../../pay.php');
				}
			}

			$_SESSION['T_CART_SUBTOTAL'] = $_SESSION['CART_SUBTOTAL'] + process_fee();
			$_SESSION['Current_Trans_Id'] = 'order_'.$_SESSION['access_key'];
		?>
			<script type="text/javascript">
				window.onload = function() { document.Form.submit(); }
			</script>


			<h1 style="text-align:center;">Processing ...</h1>
			<h3 style="text-align:center">Please Wait ...</h3>
			<div style="text-align:center; margin:20px" ><img src="Ajax_Loading.gif" alt=""/></div>

				<input name="FormMode" type="hidden" value="<?= $NextFormMode ?>" />
				<input type="hidden" name="Amount" value="<?= $_SESSION['T_CART_SUBTOTAL']*100?>" />
				<input type="hidden" name="CurrencyISOCode" value="826" />
				<input type="hidden" name="OrderID" value="<?= $_SESSION['Current_Trans_Id']?>" />
				<input type="hidden" name="OrderDescription" value="<?=  'An '.$_SESSION['RESTAURANT_TYPE_CATEGORY'].' Order. Amount '.$_SESSION['T_CART_SUBTOTAL'].' pound. By '.$_SESSION['user'].' (user id: '.$_SESSION['userId'].')'?>" />
				<input type="hidden" name="CardName" value="<?= $_SESSION['CARD_PROCESSING']['full_name'] ?>"/>
				<input type="hidden" name="CardNumber" value="<?= $_SESSION['CARD_PROCESSING']['card_no'] ?>" />

				<input type="hidden" name="ExpiryDateMonth" value="<?= $_SESSION['CARD_PROCESSING']['MM'] ?>" />
				<input type="hidden" name="ExpiryDateYear" value="<?= $_SESSION['CARD_PROCESSING']['YYYY'] ?>" />
				<input type="hidden" name="IssueNumber" value="<?= $IssueNumber ?>"/>
				<input type="hidden" name="CV2" value="<?= $_SESSION['CARD_PROCESSING']['csc'] ?>" />

				<!--<input type="hidden" name="Address1" value="<?= $_SESSION['CARD_PROCESSING']['address'] ?>"/>-->
				<input type="hidden" name="Address1" value="11 St Kitts Close,Torquay,Devon"/>
				<input type="hidden" name="Address2" value="<?= $Address2 ?>"/>
				<input type="hidden" name="Address3" value="<?= $Address3 ?>"/>
				<input type="hidden" name="Address4" value="<?= $Address4 ?>"/>
				<input type="hidden" name="StartDateMonth" value="<?= $StartDateMonth ?>"/>
				<input type="hidden" name="StartDateYear" value="<?= $StartDateYear ?>"/>
				<input type="hidden" name="City" value="<?= $City ?>"/>
				<input type="hidden" name="State" value="<?= $State ?>"/>
				<input type="hidden" name="PostCode" value="TQ2 7DQ"/>
				<input type="hidden" name="CountryISOCode" value="826"/>
<?php
		break;
	}
?>
</form>
</body>
</html>